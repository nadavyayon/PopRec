function incorporate_loaded_stack(stack)
% incorporate newly loaded tiled image stacks.
global cgui
if ~isempty (stack)
    % integrate stack and set on top:
    cgui.stk.M {end+1} = stack.M {1}; cgui.stk.sM {end+1} = stack.sM {1};
    % set a threshold corresponding to brightness values of stack:
    cgui_tree_HotWired ('thr_setstd');
    cgui.stk.coord (end + 1, :) = [0 0 0];
    % update popup (stack becomes active stack):
    set (cgui.stk.ui.pop, 'string', cgui.stk.sM, 'value', length (cgui.stk.sM));
    cgui_tree_HotWired ('stk_update'); % update stk_ maximum intensity projections
    cgui_tree_HotWired ('stk_image'); % redraw stk_ graphical output: image stacks
    cgui_tree_HotWired ('thr_image'); % redraw thr_ graphical output: thresholded stacks
    % activate ui elements and text output stack size:
    cgui_tree_HotWired ('stk_showpanels'); cgui_tree_HotWired ('stk_inform');
end
end