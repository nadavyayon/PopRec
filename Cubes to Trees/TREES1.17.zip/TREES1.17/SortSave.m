%This function sort a swc, it first find the roots of the tree and then
%sort it.


%pathToLoadSwc - the path to the swc that need to be sorted , (example 'c:/.../Cell1.swc')
%pathToSaveSwc - the path to save the swc in, need to end with swc   (example 'c:/.../Cell1_sorted.swc')
function SortSave(pathToLoadSwc, pathToSaveSwc,Diam)
    echo off
    dat = importdata(pathToLoadSwc);
%     dat.data = deleteShortBranchestoSoma(dat.data,dat.data(1,6));
    SortReconstruction_path(dat.data,pathToSaveSwc,Diam);
end    
    
    
function [denArray,CleanData] = SortReconstruction_path(data,saveDirec,Diam)
    MinArr = find(data(:,7)==-1); % find all location that have -1 ( find all roots)
    if length(MinArr)>1
        throw('Error the reconstruction contain more then 1 root, contact Oren, oren.a4@gmail.com');
    end
    
    for i=1:length(MinArr)
        clear Te;
        Te=FixVaa3(data,MinArr(i));  % extract theis tree from the data
        denArray{i}=Te;
        if nargin>1
            Save_swc(saveDirec,Te,Diam);
        end
    end
    CleanData = removeExtracted(data,denArray);
end

function data1 = removeExtracted(data,denArray)
    data1 = data;
    length(denArray);
    for i=1:length(denArray)
        for j=1:length(denArray{i})
            q = find(data1(:,3).*data1(:,4)+data1(:,5) == denArray{i}(j,3).*denArray{i}(j,4)+denArray{i}(j,5));
            if length(q)>1
                Som =  ' there are more then two values that has the same x point as the one that is in dendrite that was extracted';
                Som1 = ' denArray';
                i;
                Som2 = 'Position in denarray';
                j;
                return
            elseif length(q)==1
                data1(q,:)=[];
            end
        end
    end
end



% need to find  -1 samples and put it in z

function Rec = FixVaa3(data2,root)
    clear global dataR
    clear global Rec
    global dataR;  %iTS Workinf WITH global variables so the make the recurrsion cheaper.
    global Rec;
    z=root;    % need to find  -1 samples and put it in z
    dataR=data2;
    global count;
    count=1;
    count1=1;
    set(0,'RecursionLimit',1900)
    Rec(count,2:7)=dataR(z,2:7);
    Rec(count,1)=count;
    count=count+1;
    a = find(dataR(:,7) == z );

    getnode(a,count1);
end

function  AA= getnode(z,count1)
    global dataR;
    global Rec;
    global count;
    for i=1:length(z)
        if i~=1
            print ='a';
            i;
        end

        Rec(count,2:6) = dataR(z(i),2:6);
        Rec(count,1)=count;
        Rec(count,7)=count1;
        count=count+1;
        q= find(dataR(:,7) == z(i));

        getnode(q,double(count)-1);
    end
    AA=1;
end


function NewData = deleteShortBranchestoSoma(Data,Radius)
    PointsToDelete = [];
    CentreBranches = find(Data(:,7)==1);
    for i = 1:length(CentreBranches);
        counter = 0;
        CurrentPoint = CentreBranches(i);
        Branch = [];
        HasNextNode = 1;
        while HasNextNode == 1;
            counter = counter+1;
            if size(CurrentPoint,1)>1; 
                HasNextNode=0;  
                Flag = 1;
            else
                Branch(counter) = CurrentPoint
                CurrentPoint = find(Data(:,7)== CurrentPoint)
                HasNextNode = ~isempty(CurrentPoint)
            end
        end
        LastPoint = Branch(end); 
        if (pdist([Data(LastPoint,3:5); Data(1,3:5)])<Radius) && ~Flag
            PointsToDelete = [PointsToDelete; Branch'];
        end
        Flag = 0;
    end
if ~isempty(PointsToDelete)
    PointToKeep = ones(size(Data,1),1);
    PointToKeep(PointsToDelete) = 0; 
    NewData = Data(find(PointToKeep),:);
end

end


function Rpath = Save_swc(Repath,Data,Diam)
    swcfile = fopen(Repath,'w'); % open file
    SomaInd = find(Data(:,6)>=Data(1,6));
    SomaNotInd = find(Data(:,6)< Data(1,6));
    Data(SomaInd,6) = Diam; %set correct diams 
    Data(SomaInd,2) = 1; %affiliate to soma
    Data(SomaNotInd,2) = 3; %affiliate to dendrite
    Data(SomaNotInd,6) = Data(SomaNotInd,6)/2 ; %Shrink Dendrite diameter by hlaf 
    fwrite  (swcfile, ['# swc Data',char(10)]);
    fprintf (swcfile, '%d %d %12.8f %12.8f %12.8f %12.8f %d\n', Data');
    fclose  (swcfile);
end
