% HSS_TREE    load a sample HSS cell
%
% the TREES toolbox: edit, visualize and analyze neuronal trees
% Copyright (C) 2009  Hermann Cuntz

function hss = hss_tree

hss = load_tree('hss.mtr','none');