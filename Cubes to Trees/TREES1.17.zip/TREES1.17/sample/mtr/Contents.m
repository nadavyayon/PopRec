% SAMPLE TREES
%
% Files
%   hsn_tree     - load a sample HSN cell
%   hss_tree     - load a sample HSS cell
%   sample2_tree - load a simple sample tree
%   sample_tree  - load a subtree of a sample HSN cell
%
% the TREES toolbox: edit, visualize and analyze neuronal trees
% Copyright (C) 2009  Hermann Cuntz

