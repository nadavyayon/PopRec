% SAMPLE_TREE    load a subtree of a sample HSN cell
%
% the TREES toolbox: edit, visualize and analyze neuronal trees
% Copyright (C) 2009  Hermann Cuntz

function sample = sample_tree

sample = load_tree('sample.mtr','none');