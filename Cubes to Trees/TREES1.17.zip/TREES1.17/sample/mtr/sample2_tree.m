% SAMPLE2_TREE    load a simple sample tree
%
% the TREES toolbox: edit, visualize and analyze neuronal trees
% Copyright (C) 2009  Hermann Cuntz

function sample2 = sample2_tree

sample2 = load_tree('sample2.mtr','none');