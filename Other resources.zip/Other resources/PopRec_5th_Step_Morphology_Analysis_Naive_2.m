% Morphology Analysis Naive Mice
%% Load data 
close all 
clc
clear 

BatchDir = 'E:\PopRecData\NaiveMice\OnlyCellsInBarrels_100120'; %path to CSV with Feature Data
cd(BatchDir) 
fileinfo = dir('*.csv');
BatchDataFiles = cell(1,length(fileinfo));
for d = 1:length(fileinfo)
   BatchDataFiles{d} = readtable(fileinfo(d).name);
end

% Metadata 

%R is 0 L is 1
Sides(1) = 0;
Sides(2) = 1;
Sides(3) = 0;
Sides(4) = 1;
Sides(5) = 0;
Sides(6) = 1;
Sides(7) = 0;
Sides(8) = 1;
Sides(9) = 0;
Sides(10) = 1;
Sides(11) = 0;
Sides(12) = 1;
Sides(13) = 0;
Sides(14) = 1;

% 0 is male 1 is female 
Gender(1) = 0;
Gender(2) = 0;
Gender(3) = 0;
Gender(4) = 0;
Gender(5) = 1;
Gender(6) = 1;
Gender(7) = 1;
Gender(8) = 1;
Gender(9) = 1;
Gender(10) = 1;
Gender(11) = 0;
Gender(12) = 0;
Gender(13) = 1;
Gender(14) = 1;

% 1 include 0 exclude in analysis 
Include(1) = 1;
Include(2) = 1;
Include(3) = 1;
Include(4) = 1;
Include(5) = 1;
Include(6) = 1;
Include(7) = 1;
Include(8) = 1;
Include(9) = 1;
Include(10) = 1;
Include(11) = 1;
Include(12) = 1;
Include(13) = 1;
Include(14) = 1;


%% Feature Selection
% see
% https://neurom.readthedocs.io/en/latest/_neurom_build/neurom.fst.get.html
% For details about specific features


Fetures = {
    'all_mean_total_length';
    'all_mean_local_bifurcation_angle';
     'all_mean_segment_meander_angle';
    'all_mean_section_term_radial_distance';
    'all_mean_section_radial_distance';
     'all_mean_segment_length';
    'all_mean_number_of_section';
    'all_mean_section_bif_length';
    'all_mean_principal_direction_extent';
    'all_mean_section_tortuosity';
    'all_mean_section_path_distance';
    'all_mean_section_branch_order';
    'all_mean_section_bif_radial_distance';
    'all_mean_section_term_branch_order';
    'all_mean_number_of_sections_per_neurite';
    'all_mean_number_of_termination';
    'all_mean_number_of_bifurcation';
    'all_mean_number_of_neurite';
    'all_mean_number_of_segment';
    'all_mean_number_of_forking_point';
    'all_mean_section_strahler_order';
    'all_mean_section_length';
    'all_mean_terminal_path_lengths_per_neurite';
    'all_mean_segment_radial_distance';
    'all_mean_section_bif_branch_order';
    'all_mean_section_term_length';
    'all_mean_section_end_distance';
    'all_mean_neurite_length';
    'Relative_Cortical_Depth'
    'allmean_trunk_angle'
    
    'IndividialSholl_1'
    'IndividialSholl_2'
    'IndividialSholl_3'
    'IndividialSholl_4'
    'IndividialSholl_5'
    'IndividialSholl_6'
    'IndividialSholl_7'
    'IndividialSholl_8'
    'IndividialSholl_9'
    'IndividialSholl_10'
    'IndividialSholl_11'
    'IndividialSholl_12'
    };


%% Group Data from individual samples
close all
clc

AllData = [BatchDataFiles];
[All_Data_Comb_tag_Females, FileNamesFemales] = ArrangeData(Include,Gender,1,AllData,Fetures,Sides);
[All_Data_Comb_tag_Males, FileNamesMales] = ArrangeData(Include,Gender,0,AllData,Fetures,Sides);
 
%% Arrange Data and exclude missing values 
All_Data_Tag = [[All_Data_Comb_tag_Males zeros(length(All_Data_Comb_tag_Males),1)]; [All_Data_Comb_tag_Females ones(length(All_Data_Comb_tag_Females),1)]];
All_Names_Tag = [FileNamesMales; FileNamesFemales];
counter = 0;
All_Data_Tag_NoNan = [];
for i = 1:length(All_Data_Tag)
  if ~isnan(sum(All_Data_Tag(i,:))) 
        counter = counter+1;
       All_Data_Tag_NoNan(counter,:) = All_Data_Tag(i,:);
  end
end

tbl1 = array2table(All_Data_Tag_NoNan ,'VariableNames',[Fetures' {'Side'} {'Gender'} ]');
tbl2 = array2table(All_Names_Tag(:,1),'VariableNames',[{'CellName'}]);
tbl3 = array2table(cell2mat(All_Names_Tag(:,2)),'VariableNames',[{'CortexNo'}]);


counter = 0;
MouseNo = zeros(height(tbl2),1);
Side = zeros(height(tbl2),1);

for i = 1:2:14
    counter = counter+1;
    Mouse = ((tbl3.CortexNo) == i)+((tbl3.CortexNo) == i+1) ;
    SideInd1 = ((tbl3.CortexNo) == i) ;
    SideInd2 = ((tbl3.CortexNo) == i+1) ;
    Side(SideInd1) = Sides(i)+1;
    Side(SideInd2) = Sides(i+1)+1;

    MouseNo(find(Mouse)) = counter;
end
 Alltbl = [tbl1 tbl2 tbl3 array2table(MouseNo,'VariableNames',[{'MouseNumber'}]) array2table(Side,'VariableNames',[{'CorticalSide'}])];




%%  Bipolar Multipolar selection

ClusterIndex = ones(height(Alltbl),1)*2;
ClusterIndex(Alltbl.all_mean_number_of_neurite==2) = 1;
ClusterIndex(Alltbl.all_mean_number_of_neurite==1) = 0; %Bi - 1, Multi - 2 ,  0-single;

Alltbl = [Alltbl array2table(ClusterIndex ,'VariableNames',[{'ClusterIndex'} ]')];
Alltbl.Gender = Alltbl.Gender+1;
Alltbl = Alltbl(Alltbl.ClusterIndex>0,:);
Alltbl = [Alltbl array2table(Alltbl.all_mean_principal_direction_extent./Alltbl.all_mean_neurite_length ,'VariableNames',[{'Relative_Principal_Direction_Extent'} ]')]; % add relative Principal direction extent


%% Bi multi cluster
close all 
Means = [];
SEM = [];
CoHensD = [];
MeansAllCorrected = [];
SEM_R_AllCorrected = [];
SEMAll = [];
Coeff = [];
counter = 0;
LastPVal = [];
plot = 1;

for Var = [29]
    counter = counter+1;
    clc
    close all
GroupBipolar = Alltbl{Alltbl.ClusterIndex==1,Var};
GroupMultipolar = Alltbl{Alltbl.ClusterIndex==2,Var};


  formula = [Alltbl.Properties.VariableNames{Var},' ~ ClusterIndex + (1|MouseNumber) + (1|CortexNo) + (1|CorticalSide) + (1|Gender)'];
  lme = fitlme(Alltbl,formula);

  if counter == 1 
      Coeff = dataset2table(lme.Coefficients); 
  else
      Coeff = [Coeff; dataset2table(lme.Coefficients)]; 
  end
R = residuals(lme);
MeanBi = Coeff.Estimate(counter*2-1);
MeanMult = MeanBi + Coeff.Estimate(counter*2);

BipolarRValues = R(Alltbl.ClusterIndex==1);
MultipolarRValues = R(Alltbl.ClusterIndex==2);

SDBiR = std(BipolarRValues);
SDMultR = std(MultipolarRValues);

CoHensD(counter,1) = abs(MeanBi-MeanMult)/sqrt((SDBiR^2 + SDMultR^2)/2)
Means = [MeanBi MeanMult];
SEsR = [ SDBiR/sqrt(sum(Alltbl.ClusterIndex==1)) SDMultR/sqrt(sum(Alltbl.ClusterIndex==2))];

 MeansAllCorrected = [MeansAllCorrected; Means'];
 SEM_R_AllCorrected = [SEM_R_AllCorrected; SEsR'];



if plot
    figure()
    hold all
    h1 = histogram((GroupBipolar),50,'FaceColor',[0 0.4470 0.7410]);
    h2 = histogram((GroupMultipolar),50,'FaceColor',[0.4660 0.6740 0.1880]);
    set(gca,'FontSize',16)
    fig = gcf; % current figure handle
    fig.Color = 'w';
    ylabel('Number of Neurons')
    legend('Bipolar','Multipolar');
    width = h2.BinWidth ;
    h1.BinWidth = width; 
    h2.BinWidth = width;
    title([strrep(strrep(Alltbl.Properties.VariableNames{Var},'_',' '),'all ',''),', Cohen''s D - ',num2str(round(CoHensD(counter,1),2))]);
end
% [h,p] = kstest2(GroupBipolar,GroupMultipolar);
% [ht,pt] = ttest2(GroupBipolar,GroupMultipolar);
% title(['KS Test P = ',num2str(p),', Ttest P = ',num2str(pt)]);
% Means = [mean(GroupBipolar) mean(GroupMultipolar)];
% SEM = [std(GroupBipolar)/sqrt(length(GroupBipolar)) std(GroupMultipolar)/sqrt(length(GroupMultipolar))];
% MeansAllCorrected = [MeansAllCorrected; Means'];
% SEMAll = [SEMAll; SEM'];




pause

end


%% Bi multi cluster Individual Mice
close all 
Means = [];
SEM = [];
MeansAllCorrected = [];
SEMAll = [];
mice = unique(Alltbl.MouseNumber);
lme = cell(length(mice),1)
for Var = [1:42 50]
    close
    for m = mice'
        
        
        AlltblMouse = Alltbl(Alltbl.MouseNumber==m,:);
        GroupBipolar = AlltblMouse{AlltblMouse.ClusterIndex==1,Var};
        GroupMultipolar = AlltblMouse{AlltblMouse.ClusterIndex==2,Var};
        subplot(3,3,m)
        hold all
        h1 = histogram(log10(GroupBipolar),15,'FaceColor',[0 0.4470 0.7410],'Normalization','probability');
        h2 = histogram(log10(GroupMultipolar),15,'FaceColor',[0.4660 0.6740 0.1880],'Normalization','probability');
        set(gca,'FontSize',12)
        fig = gcf; % current figure handle
        fig.Color = 'w';
        ylabel('Proportion')
        if m == 1; legend('Bipolar Cluster','Multipolar Cluster'); end

        Means = [mean(GroupBipolar) mean(GroupMultipolar)];
        SEM = [std(GroupBipolar)/sqrt(length(GroupBipolar)) std(GroupMultipolar)/sqrt(length(GroupMultipolar))];
        MeansAllCorrected = [MeansAllCorrected; Means'];
        SEMAll = [SEMAll; SEM'];
        
        fig = gcf; % current figure handle
        fig.Color = 'w';
        width = h2.BinWidth; 
        h1.BinWidth = width;
        h2.BinWidth =  width;
        title(['Mouse Number - ',num2str(m)]);

        formula = [AlltblMouse.Properties.VariableNames{Var},' ~ -1 + ClusterIndex + (1|CorticalSide) '];
        lme{m} = fitlme(AlltblMouse,formula)
    end
    suptitle(strrep(strrep(AlltblMouse.Properties.VariableNames{Var},'_',' '),'all ',''));
pause
close all
end
% h1 = histogram([GroupBipolar;GroupMultipolar],100,'FaceColor',[0 0.4470 0.7410],'Normalization','probability');

%% Correlations 

Var = [1:42 50];
ReleventData = Alltbl{:,Var};
[R,P] = corrcoef(zscore(ReleventData));
imagesc(P<0.01)
clustergram(zscore(ReleventData));


%% Bipolar Multipolar sholl

figure

meanShollbi = mean(Alltbl{Alltbl.ClusterIndex==1,31:42});
meanShollmulti = mean(Alltbl{Alltbl.ClusterIndex==2,31:42});
errShollbi = std(Alltbl{Alltbl.ClusterIndex==1,31:42});
errShollmulti = std(Alltbl{Alltbl.ClusterIndex==2,31:42});
errorbar(20*(1:12),meanShollbi,errShollbi./sqrt(sum(Alltbl.ClusterIndex==1)-1),'MarkerEdgeColor','red');
hold all
errorbar(20*(1:12),meanShollmulti,errShollmulti./sqrt(sum(Alltbl.ClusterIndex==2)-1));
legend('Bipolar','Multipolar');
xlabel('Distance From Cell Body')
ylabel('Avg Crossings')
 set(gca,'FontSize',16)
 fig = gcf; % current figure handle
fig.Color = 'w';


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%aux functions
function [PermDataSort, PermDataNamesSort] = PermAndSort(All_Comb_tag, All_Comb_Names);
    OriginalDepInd = All_Comb_tag(:,end)==1;
    OriginalUnDepInd = All_Comb_tag(:,end)==0;
    OriginalUnDepMInd = All_Comb_tag(:,end)==-1;

    ClusterIndex = All_Comb_tag(OriginalDepInd,:);
    UnClusterIndex = All_Comb_tag(OriginalUnDepInd,:);
    UnClusterIndexM = All_Comb_tag(OriginalUnDepMInd,:);

    n1 = 249;%(ClusterIndex);
    n2 = 249;%length(ClusterIndex);%length(UnClusterIndex);
    n3 = 0;
    PermIndDep = randperm(length(ClusterIndex),n1);
    PermIndUnDep = randperm(length(UnClusterIndex),n2);
    PermIndUnDepM = randperm(length(UnClusterIndexM),n3);

    NamesDep = All_Comb_Names(OriginalDepInd,:);
    NamesUnDep = All_Comb_Names(OriginalUnDepInd,:);
    NamesUnDepM = All_Comb_Names(OriginalUnDepMInd,:);


    PermDataNames = [NamesDep(PermIndDep,:); NamesUnDep(PermIndUnDep,:); NamesUnDepM(PermIndUnDepM,:)];
    PermData = [ClusterIndex(PermIndDep,:); UnClusterIndex(PermIndUnDep,:); UnClusterIndexM(PermIndUnDepM,:)];
    
    [~, sortindDep] = sort(cell2mat(PermDataNames(1:n1,2)));
    [~, sortindUnDep] = sort(cell2mat(PermDataNames(n1+1:n1+n2,2)));
    [~, sortindUnDepM] = sort(cell2mat(PermDataNames(n1+n2+1:end,2)));

    
    PermDataNamesSort = PermDataNames([sortindDep; sortindUnDep+n1; sortindUnDepM+n1+n2],:);
    PermDataSort = PermData([sortindDep; sortindUnDep+n1; sortindUnDepM+n1+n2],:);
             
end 
function All_Data_Norm_Tag = NormData(AllData,FileNames);

Unified1 = AllData(BatchIndices,1:end-2);
Unified2 = AllData(~BatchIndices,1:end-2);
Selected1 = AllData(B1MiceIndeces,1:end-2);  
Selected2 = AllData(B2MiceIndeces,1:end-2);  

%   Quantile = 0.02;
%    NormTemp1 = (Unified1 - ((1e-10)+repmat(quantile(Selected1,Quantile),size(Unified1,1),1))) ./ ( repmat(quantile(Selected1,1-Quantile),size(Unified1,1),1) - repmat(quantile(Selected1,Quantile),size(Unified1,1),1) );
%    NormTemp2 = (Unified2 - ((1e-10)+repmat(quantile(Selected2,Quantile),size(Unified2,1),1))) ./ ( repmat(quantile(Selected2,1-Quantile),size(Unified2,1),1) - repmat(quantile(Selected2,Quantile),size(Unified2,1),1) );
   NormTemp1 = (Unified1 - (repmat(mean(Selected1),size(Unified1,1),1)))./ ( repmat(std(Selected1),size(Unified1,1),1)) ;
   NormTemp2 = (Unified2 - (repmat(mean(Selected2),size(Unified2,1),1)))./ ( repmat(std(Selected2),size(Unified2,1),1)) ;


 
 All_Data_Norm_Tag = AllData;

All_Data_Norm_Tag(BatchIndices,1:end-2) = NormTemp1;
All_Data_Norm_Tag(~BatchIndices,1:end-2) = NormTemp2;
All_Data_Norm_Tag = All_Data_Norm_Tag(:,[1:size(AllData,2)-2 size(AllData,2)]) % remmove Batch Variable  
end
function  Test_sig_barplot_All(All_Comb_tag_Female,All_Comb_tag_Males,Fetures,sigthresh)

ClusterIndexF = All_Comb_tag_Female(All_Comb_tag_Female(:,end)==1,:);
UnClusterIndexF = All_Comb_tag_Female(All_Comb_tag_Female(:,end)==0,:);
DF = ClusterIndexF;
UF = UnClusterIndexF;

ClusterIndexM = All_Comb_tag_Males(All_Comb_tag_Males(:,end)==1,:);
UnClusterIndexM = All_Comb_tag_Males(All_Comb_tag_Males(:,end)==0,:);
DM = ClusterIndexM;
UM = UnClusterIndexM;



% MeanZero = ([ClusterIndex; UnClusterIndex] - mean([ClusterIndex; UnClusterIndex]));
clear prealF
for i = 1:size(All_Comb_tag_Female,2)-1
%     isnotNormal(i) = kstest(MeanZero(:,i));
%     if isnotNormal(i)
%         preal(i) = ranksum(D(:,i),U(:,i));
%     else
       [a prealF(i)] = ttest2(DF(:,i),UF(:,i));
%     end

end
SignificantNamesF = strrep(Fetures(prealF<sigthresh),'_',' ');
SignificantNamesF = strrep(SignificantNamesF,'all','');
SignificantNamesF = strrep(SignificantNamesF,'mean ',' ');
SignificantIndF = find(prealF<sigthresh);
meansDF = mean(DF(:,SignificantIndF));
meansUF = mean(UF(:,SignificantIndF));
meansDF = meansDF./meansUF;
meansUF = meansUF./meansUF;
STDEVDF = std(DF(:,SignificantIndF))./sqrt(length(DF))./meansUF;
STDEVUF = std(UnClusterIndexF(:,SignificantIndF))./sqrt(length(UnClusterIndexF))./meansUF;


clear prealM
for i = 1:size(All_Comb_tag_Males,2)-1
%     isnotNormal(i) = kstest(MeanZero(:,i));
%     if isnotNormal(i)
%         preal(i) = ranksum(D(:,i),U(:,i));
%     else
       [a prealM(i)] = ttest2(DM(:,i),UM(:,i));
%     end

end
SignificantNamesM = strrep(Fetures(prealM<sigthresh),'_',' ');
SignificantNamesM = strrep(SignificantNamesM,'all','');
SignificantNamesM = strrep(SignificantNamesM,'mean ',' ');
SignificantIndM = find(prealM<sigthresh);
meansDM = mean(DM(:,SignificantIndM));
meansUM = mean(UM(:,SignificantIndM));
meansDM = meansDM./meansUM;
meansUM = meansUM./meansUM;
STDEVDM = std(DM(:,SignificantIndM))./sqrt(length(DM))./meansUM;
STDEVUM = std(UnClusterIndexM(:,SignificantIndM))./sqrt(length(UnClusterIndexM))./meansUM;


figure
hb = bar([1:6:length(SignificantIndM)*6],[meansUM],'BarWidth',0.1)
hold all
hb = bar([2:6:length(SignificantIndM)*6],[meansDM],'BarWidth',0.1)
hb = bar([3:6:length(SignificantIndF)*6],[meansUF],'BarWidth',0.1)
hb = bar([4:6:length(SignificantIndF)*6],[meansDF],'BarWidth',0.1)


set(gca, 'XTick', [1:6:length(SignificantIndM)*6])
set(gca, 'XTickLabel', SignificantNamesM)
set(gca, 'FontSize', 14)
xtickangle(45)


% set(gca, 'FontSize',12,'XTick',[1 2],'XTickLabel',{'1.5<A.R<2.5','2.5<A.R<3.5','A.R>3.5' });
ylabel('Relative Change')
errbar = [STDEVUM' STDEVDM' STDEVUF' STDEVDF'];   % CREATE �errbar� MATRIX
yd = [ meansUM' meansDM'  meansUF' meansDF'];
xInd = 1:6:length(SignificantNamesM)*6;
hold on
for j = 1:length(SignificantNamesM)
    for k1 = 1:4
        errorbar(xInd(j)+k1-1,  yd(j,k1),  errbar(j,k1), '.k', 'LineWidth',2)
    end
end
legend('UnClusterIndex Males','ClusterIndex Males','UnClusterIndex Females','ClusterIndex Females');


hold off
end
function [All_Data_Comb_tag, NamesComb]= ArrangeData(Include,Gender,MF,AllData,Fetures,Sides);
TempTable1 = [];
TempTable2 = [];


SideNames1 = {};
SideNames2 = {};



for d = 1:2:14;
    if (Gender(d) == MF).*Include(d); % take only one gender and relevant mice
       Temp1 = zeros(height(AllData{d}),length(Fetures));
       Names1 = [AllData{d}.name, num2cell(repmat(d,length(AllData{d}.name),1))];
       for i = 1:length(Fetures)  
          eval(['Temp1(:,i) =  AllData{d}.',Fetures{i},';']);
       end
       Temp2 = zeros(height(AllData{d+1}),length(Fetures));
       Names2 = [AllData{d+1}.name, num2cell(repmat(d+1,length(AllData{d+1}.name),1))];
       for i = 1:length(Fetures)  
          eval(['Temp2(:,i) =  AllData{d+1}.',Fetures{i},';']);
       end


      %normalize within mouse 
      % replace 0 values with mouse median 
%       Unified = [];
%       NormTemp = [];
%       Unified = [Temp1;Temp2];   
%       for i = 1:length(Fetures) 
%            missingTemp{i} = find(Unified(:,i)==0);
%            if ~isempty(missingTemp{i}) 
%                Unified(missingTemp{i},i) = median(Unified(:,i));
%            end
%       end
%       Temp1 = Temp1./vecnorm(Unified);
%       Temp2 = Temp2./vecnorm(Unified);
%           NormTemp = (Unified - repmat(min(Unified),size(Unified,1),1)) ./ ( repmat(max(Unified),size(Unified,1),1) - repmat(min(Unified),size(Unified,1),1) );
%           NormTemp = (Unified - ((1e-5)+repmat(median(Unified),size(Unified,1),1)));%./ ( repmat(std(Unified),size(Unified,1),1) );
%           NormTemp = (Unified - ((1e-10)+repmat(median(Unified),size(Unified,1),1)))./ ( repmat(std(Unified),size(Unified,1),1) );
%            NormTemp = (Unified - (repmat(mean(Unified),size(Unified,1),1)));%./ ( repmat(std(Unified),size(Unified,1),1)) ;

%           histogram(NormTemp(:,1),20)
%           hold
%           histogram(Unified(:,1),20)
%             NormTemp = (Unified - ((1e-10)+repmat(quantile(Unified,0.02),size(Unified,1),1))) ./ ( repmat(quantile(Unified,0.98),size(Unified,1),1) - repmat(quantile(Unified,0.02),size(Unified,1),1) );
%           NormTemp = (Unified ./ repmat(median(Unified),size(Unified,1),1));% ./ ( repmat(std(Unified),size(Unified,1),1) );

% normalize according to unClusterIndex 

    %        add batch variable   
%             NormTemp = [Temp1;Temp2]; 
%           NormTemp  = [NormTemp repmat(Batch(d),length(Unified),1)];
%              Unified  = [Unified repmat(Batch(d),length(Unified),1)];

% 
%        
%            
         close all
%          Temp1 = NormTemp(1:length(Temp1),:);
%          Temp2 = NormTemp(length(Temp1)+1:end,:);


         if  Sides(d) % if this is Left side
          
             TempTable1 = [TempTable1; Temp1];
             TempTable2 = [TempTable2; Temp2];
             SideNames1 = [SideNames1; Names1];
             SideNames2 = [SideNames2; Names2];

         else
          
            TempTable2 = [TempTable2; Temp1];
            TempTable1 = [TempTable1; Temp2];
            SideNames1 = [SideNames1; Names2];
            SideNames2 = [SideNames2; Names1];
         end
     
    end
   clear Temp1 Temp2 Unified
  
end

NamesComb = [SideNames1; SideNames2];
Tag1 = ones(length(TempTable1),1);   
Tag2 = zeros(length(TempTable2),1);



tags = [Tag1; Tag2];
All_Comb = [TempTable1;TempTable2];
All_Data_Comb_tag = [All_Comb tags];

end
