% HSN_TREE    load a sample HSN cell
%
% the TREES toolbox: edit, visualize and analyze neuronal trees
% Copyright (C) 2009  Hermann Cuntz

function hsn = hsn_tree

hsn = load_tree('hsn.mtr','none');