
function AutoConst_V1_6(SomaLocation,FlourecenceThreshold,MaximumPointDistance,FileDir,CellNumber,XYZCubeOrigin,RealDiam)
echo off;

global cgui;
global RealSoma;
global trees;
global Diams;

BalanceFactor = 0.5;
VoxelResolution = [1 1 1];
SomaLocations = SomaLocation{:,:};
Somas = length(SomaLocations(:,1));

SomaLocations = SomaLocations + repmat([fliplr(XYZCubeOrigin(1:2)) XYZCubeOrigin(3)],Somas,1);

MinimumDistanceBetweenPoints = 3;
RealSoma = SomaLocations.*repmat(VoxelResolution,Somas,1);
Diams = 75*ones(1,size(RealSoma,1));

RealThreshold = FlourecenceThreshold;
cd(FileDir);



FileInfo = dir('*.tif');
CellNumberTemp = []; 
for i = 1:length(FileInfo)
    CellNumberTemp(i) = str2num(strrep(FileInfo(i).name(6:9),'.',''));
end
CellNumberTemp = CellNumberTemp';
cellnumberN = find(CellNumberTemp == CellNumber); %correct for natural sorting 

cgui_tree_HotWired;
set(1,'visible','off');
stack = loadtifs_stack_No_GUI([FileDir,'/',FileInfo(cellnumberN).name]);

incorporate_loaded_stack(stack);
set (cgui.thr.ui.ed_thr1, 'string',RealThreshold); % Threshold
set (cgui.thr.ui.ed_clean1, 'string',5); %cleaning threshold
set (cgui.mtr.ui.ed_mst2, 'string',MaximumPointDistance); % MaximumPointDistance
set (cgui.mtr.ui.ed_mst1, 'string',BalanceFactor); % Balancing Factor
set (cgui.skl.ui.ed_clean1, 'string', MinimumDistanceBetweenPoints); % minimum distance between points
%set (cgui.stk.ui.ed_vox3, 'string',3);
cgui.stk.voxel = VoxelResolution;
cgui.stk.coord  = XYZCubeOrigin.*VoxelResolution; % 
cgui_tree_HotWired('stk_auto');


length (trees);
cd(FileDir);
%NEED TO DO :define scale for xyz
if sum(XYZCubeOrigin)>3
    cgui.mtr.tree
    swc_tree (cgui.mtr.tree,[FileDir,'/SWC/',FileInfo(cellnumberN).name(1:end-4),'_XYZ.swc']); %original base coordinates 
    SortSave([FileDir,'/SWC/',FileInfo(cellnumberN).name(1:end-4),'_XYZ.swc'],[FileDir,'/SWC/Sorted/FT_',num2str(FlourecenceThreshold),'_MPD_',num2str(MaximumPointDistance),'/',FileInfo(cellnumberN).name(1:end-4),'_MPD_',num2str(MaximumPointDistance),'_FT_',num2str(FlourecenceThreshold),'_XYZ_Sorted.swc'],RealDiam/3);

else   
    swc_tree (cgui.mtr.tree,[FileDir,'/SWC/',FileInfo(cellnumberN).name(1:end-4),'.swc']); %Zeroed base coordinates 
    SortSave([FileDir,'/SWC/',FileInfo(cellnumberN).name(1:end-4),'.swc'],[FileDir,'/SWC/Sorted/FT_',num2str(FlourecenceThreshold),'_MPD_',num2str(MaximumPointDistance),'/',FileInfo(cellnumberN).name(1:end-4),'_MPD_',num2str(MaximumPointDistance),'_FT_',num2str(FlourecenceThreshold),'.swc'],RealDiam/3);

end

close all force
clc
end