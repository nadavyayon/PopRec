startpath  = '~/All_Mice_DOB_151118';

FilesDirectory =    [startpath,'/SingleCells',num2str(FilesDirectory,'%02.f')];
addpath(genpath('~/'))

load ([FilesDirectory,'/SomaCoordinates.mat']);
load ([FilesDirectory,'/XYZCubeOrigins.mat']);
load ([FilesDirectory,'/SomaDiams.mat']);
Diameter = Diams(Cell);
SomaCord = SomaCoordinates(Cell);
XYZ = XYZCubeOrigins(Cell,:);
start_trees
% XYZ = [0 0 0]; %local coordinates

warning('off','MATLAB:HandleGraphics:noJVM')
AutoConst_V1_6(SomaCord,FT,MPD,FilesDirectory,Cell,XYZ,Diameter); % Original coordinates 

