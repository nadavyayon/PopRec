
%% auto reconstruct 

clear all 
clc
startpath  = '~/GenderDiferrences';
warning('off','all'); %disable warnings

   
tic
AnalysisPath =   {
   'All_Mice_DOB_151118/SingleCells01';
   'All_Mice_DOB_151118/SingleCells02';
   'All_Mice_DOB_151118/SingleCells03';
   'All_Mice_DOB_151118/SingleCells04';
   'All_Mice_DOB_151118/SingleCells05';
   'All_Mice_DOB_151118/SingleCells06';
   'All_Mice_DOB_151118/SingleCells07';
   'All_Mice_DOB_151118/SingleCells08';
   'All_Mice_DOB_151118/SingleCells09';
   'All_Mice_DOB_151118/SingleCells10';
   'All_Mice_DOB_151118/SingleCells11';
   'All_Mice_DOB_151118/SingleCells12';
   'All_Mice_DOB_151118/SingleCells13';
   'All_Mice_DOB_151118/SingleCells14';
   
};        
for i = 1:length(AnalysisPath)
    AnalysisPathCells{i} = (AnalysisPath{i});
    FileDir{i} = [startpath,'/' ,AnalysisPathCells{i}];
end

FTValues = [10 50 100];
MPDValues = [6 8 10 12];
for i = 1:length(AnalysisPath)
    mkdir([FileDir{i},'/SWC']);
    mkdir([FileDir{i},'/SWC/Sorted']);
    for FlourecenceThreshold = FTValues
        for MaximumPointDistance = MPDValues
            mkdir([FileDir{i},'/SWC/Sorted/FT_',num2str(FlourecenceThreshold),'_MPD_',num2str(MaximumPointDistance)]);
        end
    end
end

tic
for i = 5%1:length(AnalysisPath)
    cd(FileDir{i})
    load ('SomaCoordinates.mat');
    load ('XYZCubeOrigins.mat');
    for FlourecenceThreshold = FTValues
        for MaximumPointDistance = MPDValues
            RandCells = randperm(size(SomaCoordinates,1));
            for Cell = RandCells;
                    cd(startpath)
                    warning('off','all');
                    txt = ['FT=', num2str(FlourecenceThreshold), ';MPD=', num2str(MaximumPointDistance),';AF=1;Cell=',num2str(Cell),';FilesDirectory=',num2str(i,'%02.f')]
                    system(['qsub -b y -o output.txt -e error.txt "matlab -nodisplay -r ''', txt ,';Run120819; exit ''"']);              
            end
        end
    end
end
toc
warning('off','all'); %disable warnings
