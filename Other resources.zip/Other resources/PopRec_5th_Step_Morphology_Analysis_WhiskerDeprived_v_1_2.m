%analysis for whisker deprived mice 

%% Load data 
%close all 
clc
clear 
BatchDir = 'E:\PROJECTS\EMCU\4thWhiskerDeprived\SomaToCube\OutputOnlyBarrels';
cd(BatchDir) 
fileinfo = dir('*.csv');
DataFiles = cell(1,24);
for d = 1:24
   DataFiles{d} = readtable(fileinfo(d).name);
end
%% Metadata

% Sample Identity 
% Side
% A3 - Mouse_01_Side_00 - Left - UD
% A3 - Mouse_01_Side_01 - Right - UD
% A7 - Mouse_02_Side_00 - Right - RD
% A7 - Mouse_02_Side_01 - Left - RD
% D7 - Mouse_03_Side_00 - Left - RD
% D7 - Mouse_03_Side_01 - Right - RD
% A8 - Mouse_04_Side_00 - Left - LD
% A8 - Mouse_04_Side_01 - Right - LD
% B3 - Mouse_05_Side_00 - Right - UD 
% B3 - Mouse_05_Side_01 - Left - UD
% B5 - Mouse_06_Side_00 - Left - RD
% B5 - Mouse_06_Side_01 - Right - RD
% B6 - Mouse_07_Side_00 - Right - UD
% B6 - Mouse_07_Side_01 - Left - UD
% C4 - Mouse_08_Side_00 - Right - LD
% C4 - Mouse_08_Side_01 - Left - LD
% C8 - Mouse_09_Side_00 - Left - LD 
% C8 - Mouse_09_Side_01 - Right - LD
% D4 - Mouse_10_Side_00 - Right - RD 
% D4 - Mouse_10_Side_01 - Left - RD
% D6 - Mouse_11_Side_00 - Left - UD
% D6 - Mouse_11_Side_01 - Right - UD
% D3 - Mouse_12_Side_00 - Right - LD 
% D3 - Mouse_12_Side_01 - Left - LD


%Sample Number

SampleNo(1)=1;
SampleNo(2)=2;
SampleNo(3)=3;
SampleNo(4)=4;
SampleNo(5)=5;
SampleNo(6)=6;
SampleNo(7)=7;
SampleNo(8)=8;
SampleNo(9)=9;
SampleNo(10)=10;
SampleNo(11)=11;
SampleNo(12)=12;
SampleNo(13)=13;
SampleNo(14)=14;
SampleNo(15)=15;
SampleNo(16)=16;
SampleNo(17)=17;
SampleNo(18)=18;
SampleNo(19)=19;
SampleNo(20)=20;
SampleNo(21)=21;
SampleNo(22)=22;
SampleNo(23)=23;
SampleNo(24)=24;


%R is 0 L is 1

Sides(1)=1;
Sides(2)=0;
Sides(3)=0;
Sides(4)=1;
Sides(5)=1;
Sides(6)=0;
Sides(7)=1;
Sides(8)=0;
Sides(9)=0;
Sides(10)=1;
Sides(11)=1;
Sides(12)=0;
Sides(13)=0;
Sides(14)=1;
Sides(15)=0;
Sides(16)=1;
Sides(17)=1;
Sides(18)=0;
Sides(19)=0;
Sides(20)=1;
Sides(21)=1;
Sides(22)=0;
Sides(23)=0;
Sides(24)=1;


% 1 Is Deprived 0 is undeprived side

Deprived(1)=0;
Deprived(2)=0;
Deprived(3)=0;
Deprived(4)=1;
Deprived(5)=1;
Deprived(6)=0;
Deprived(7)=0;
Deprived(8)=1;
Deprived(9)=0;
Deprived(10)=0;
Deprived(11)=1;
Deprived(12)=0;
Deprived(13)=0;
Deprived(14)=0;
Deprived(15)=1;
Deprived(16)=0;
Deprived(17)=0;
Deprived(18)=1;
Deprived(19)=0;
Deprived(20)=1;
Deprived(21)=0;
Deprived(22)=0;
Deprived(23)=1;
Deprived(24)=0;

% 1 Is DeprivedMouse 0 is unDeprivedMouse 

DeprivedMouse(1)=0;	
DeprivedMouse(2)=0;	
DeprivedMouse(3)=1;	
DeprivedMouse(4)=1;	
DeprivedMouse(5)=1;	
DeprivedMouse(6)=1;	
DeprivedMouse(7)=1;	
DeprivedMouse(8)=1;	
DeprivedMouse(9)=0;	
DeprivedMouse(10)=0;	
DeprivedMouse(11)=1;	
DeprivedMouse(12)=1;	
DeprivedMouse(13)=0;	
DeprivedMouse(14)=0;	
DeprivedMouse(15)=1;	
DeprivedMouse(16)=1;	
DeprivedMouse(17)=1;	
DeprivedMouse(18)=1;	
DeprivedMouse(19)=1;	
DeprivedMouse(20)=1;	
DeprivedMouse(21)=0;	
DeprivedMouse(22)=0;	
DeprivedMouse(23)=1;	
DeprivedMouse(24)=1;	

% 1 include 0 exclude in analysis 

Include(1)=1;
Include(2)=1;
Include(3)=1;
Include(4)=1;
Include(5)=1;
Include(6)=1;
Include(7)=1;
Include(8)=1;
Include(9)=1;
Include(10)=1;
Include(11)=1;
Include(12)=1;
Include(13)=1;
Include(14)=1;
Include(15)=1;
Include(16)=1;
Include(17)=1;
Include(18)=1;
Include(19)=1;
Include(20)=1;
Include(21)=1;
Include(22)=1;
Include(23)=1;
Include(24)=1;


Batch(1)=1;
Batch(2)=1;
Batch(3)=1;
Batch(4)=1;
Batch(5)=1;
Batch(6)=1;
Batch(7)=1;
Batch(8)=1;
Batch(9)=1;
Batch(10)=1;
Batch(11)=1;
Batch(12)=1;
Batch(13)=1;
Batch(14)=1;
Batch(15)=1;
Batch(16)=1;
Batch(17)=1;
Batch(18)=1;
Batch(19)=1;
Batch(20)=1;
Batch(21)=1;
Batch(22)=1;
Batch(23)=1;
Batch(24)=1;

InternalMouseNumber(1)=1;
InternalMouseNumber(2)=1;
InternalMouseNumber(3)=2;
InternalMouseNumber(4)=2;
InternalMouseNumber(5)=3;
InternalMouseNumber(6)=3;
InternalMouseNumber(7)=4;
InternalMouseNumber(8)=4;
InternalMouseNumber(9)=5;
InternalMouseNumber(10)=5;
InternalMouseNumber(11)=6;
InternalMouseNumber(12)=6;
InternalMouseNumber(13)=7;
InternalMouseNumber(14)=7;
InternalMouseNumber(15)=8;
InternalMouseNumber(16)=8;
InternalMouseNumber(17)=9;
InternalMouseNumber(18)=9;
InternalMouseNumber(19)=10;
InternalMouseNumber(20)=10;
InternalMouseNumber(21)=11;
InternalMouseNumber(22)=11;
InternalMouseNumber(23)=12;
InternalMouseNumber(24)=12;


% Sex
% A3 - F
% A7 - F
% D7 - M
% A8 - M
% B3 - M
% B5 - M
% B6 - F
% C4 - M
% C8 - F
% D4 - F
% D6 - M
% D3 - M

%0 is male, 1 - Female
Gender(1)=1;
Gender(2)=1;
Gender(3)=1;
Gender(4)=1;
Gender(5)=0;
Gender(6)=0;
Gender(7)=0;
Gender(8)=0;
Gender(9)=0;
Gender(10)=0;
Gender(11)=0;
Gender(12)=0;
Gender(13)=1;
Gender(14)=1;
Gender(15)=0;
Gender(16)=0;
Gender(17)=1;
Gender(18)=1;
Gender(19)=1;
Gender(20)=1;
Gender(21)=0;
Gender(22)=0;
Gender(23)=0;
Gender(24)=0;


%%  Feature Selection

Fetures = {
    'name';
    'all_mean_total_length';
    'all_mean_local_bifurcation_angle';
    'all_mean_segment_meander_angle';
    'all_mean_section_term_radial_distance';
    'all_mean_section_radial_distance';
    'all_mean_segment_length';
    'all_mean_number_of_section';
    'all_mean_section_bif_length';
    'all_mean_principal_direction_extent';
    'all_mean_section_tortuosity';
    'all_mean_section_path_distance';
    'all_mean_section_branch_order';
    'all_mean_section_bif_radial_distance';
    'all_mean_section_term_branch_order';
    'all_mean_number_of_sections_per_neurite';
    'all_mean_number_of_termination';
    'all_mean_number_of_bifurcation';
    'all_mean_number_of_neurite';
    'all_mean_number_of_segment';
    'all_mean_number_of_forking_point';
    'all_mean_section_strahler_order';
    'all_mean_section_length';
    'all_mean_terminal_path_lengths_per_neurite';
    'all_mean_segment_radial_distance';
    'all_mean_section_bif_branch_order';
    'all_mean_section_term_length';
    'all_mean_section_end_distance';
    'all_mean_neurite_length';
    'Relative_Cortical_Depth'
    'allmean_trunk_angle'
    'IndividialSholl_1'
    'IndividialSholl_2'
    'IndividialSholl_3'
    'IndividialSholl_4'
    'IndividialSholl_5'
    'IndividialSholl_6'
    'IndividialSholl_7'
    'IndividialSholl_8'
    'IndividialSholl_9'
    'IndividialSholl_10'
    'IndividialSholl_11'
    'IndividialSholl_12'
    }


%% For deprived vs undeprived 
close all
clc
AllData = [DataFiles];
AllDataTag = array2table(zeros(1,length(Fetures)+8));
AllDataTag.Properties.VariableNames = [Fetures', {'Side'},{'Deprived'},{'Deprived_Mouse'},{'include'},{'batch'},{'Internal_No'},{'Sex'},{'SampleNo'}];

for d = 1:length(AllData)
    HightTemp = height(AllData{d});    
    Tm = ones(HightTemp,1);
    M = [Tm*Sides(d) Tm*Deprived(d) Tm*DeprivedMouse(d) Tm*Include(d) Tm*Batch(d) Tm*InternalMouseNumber(d) Tm*Gender(d) Tm*SampleNo(d)];
    Mt = array2table(M);
    Mt.Properties.VariableNames = [{'Side'},{'Deprived'},{'Deprived_Mouse'},{'include'},{'batch'},{'Internal_No'},{'Sex'},{'SampleNo'}];
    AllDataTag = [AllDataTag;  [AllData{d}(:,Fetures) Mt]];
end
All_Data_Tag = AllDataTag(2:end,:);

%% arrange data
counter = 0;
All_Data_Tag_NoNan = All_Data_Tag(1,:);
for i = 1:height(All_Data_Tag)
  if ~isnan(sum(All_Data_Tag{i,2:end})) 
                counter = counter+1;
                 All_Data_Tag_NoNan(counter,:) = All_Data_Tag(i,:);
  end
end
SelectedF = [2:31];
Y = tsne(zscore(All_Data_Tag_NoNan{:,SelectedF}));


%%
var = 31
clc
close all
counter = 0;
clear Tags
figure(1)   
var = var+1
for Var = [30]
    counter = counter+1;
    for i = 1:length(Y)   
    %             Tags(i) = round((All_Data_Tag_NoNan(i,Var))*10);
%                     Tags(i) = (Names{i,2*D}<9);
%                        Tags(i) = round(10*(RelevantGroup{D}{i,Var})./quantile(RelevantGroup{D}{:,Var},0.95));
                         Tags(i) =All_Data_Tag_NoNan{i,Var};
%     if All_Data_Tag(i,end)
%         if All_Data_Tag(i,end-1)
%             Tags{i} = 'Female ';
%         else

%             Tags{i} = 'Female ';
%         end
%     else
%          if All_Data_Tag(i,end-1)
%             Tags{i} = 'Male ';
%         else
%             Tags{i} = 'Male ';
%          end
%     end
    end
    if mod(Tags(1),1)~=0 
        Tags = Tags - min(Tags) +1;
        Tags = round(rescale(Tags,1,10));
    else 
        Tags = round(Tags);
    end
map = log2(parula(length(unique(Tags)))+1);
% map = parula(length(unique(Tags)));
% subplot(2,6,counter)
gscatter(Y(:,1),Y(:,2),Tags',map,'.',10);
title([strrep(strrep(All_Data_Tag_NoNan.Properties.VariableNames{Var},'_',' '),'all ','')])
% xlabel('t-SNE, PC1');
% ylabel('t-SNE, PC2');
Var

% pause
end

%%  dep un table 
clc
TempCell = cell(height(All_Data_Tag_NoNan),1);
TempCell(All_Data_Tag_NoNan.Deprived == 1) = {'c_Cortex_Contra'} ;
TempCell( find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1))) = {'b_Cortex_Ipsi'} ;
TempCell(All_Data_Tag_NoNan.Deprived_Mouse == 0) = {'a_Cortex_Undeprived_Mouse'} ;
All_Data_Tag_NoNan.batch = logical(All_Data_Tag_NoNan.batch-1);
All_Data_Tag_NoNan.Sex = logical(All_Data_Tag_NoNan.Sex);
All_Data_Tag_NoNan.Side = logical(All_Data_Tag_NoNan.Side-1);
All_Data_Tag_NoNan = [All_Data_Tag_NoNan array2table(TempCell,'VariableNames',[{'Cortex_Condition'} ]')]; % add relative Principal direction extent
% All_Data_Tag_NoNan = sortrows(All_Data_Tag_NoNan,'Cortex_Condition','ascend');
All_Data_Tag_NoNan = [All_Data_Tag_NoNan array2table(All_Data_Tag_NoNan.all_mean_principal_direction_extent./All_Data_Tag_NoNan.all_mean_neurite_length ,'VariableNames',[{'Relative_Principal_Direction_Extent'} ]')]; % add relative Principal direction extent
%% Contra Vs Ipsi
MeansAll = [];
SEMAll = [];
Coeff = [];
SEM_R_All = [];

close all
counter = -1;
LastPVal = [];
for Var = [30]
  
formula = [All_Data_Tag_NoNan.Properties.VariableNames{Var},' ~ Cortex_Condition + (1|Side) + (1|Sex)'];

lme = fitlme(All_Data_Tag_NoNan,formula);


counter = counter + 3 ;
Coeff(counter,:) = double(lme.Coefficients(1,2:end));
Coeff(counter+1,:) = double(lme.Coefficients(2,2:end));
Coeff(counter+2,:) = double(lme.Coefficients(3,2:end));
LastPVal(counter) =  coefTest(lme,[0 1 -1]);
R = residuals(lme);


Deprived_Ipsi = All_Data_Tag_NoNan{All_Data_Tag_NoNan.Deprived == 1,Var};
Deprived_Contra = All_Data_Tag_NoNan{find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1)),Var};
Undep_Mouse = All_Data_Tag_NoNan{All_Data_Tag_NoNan.Deprived_Mouse == 0,Var};

Deprived_IpsiR = R(All_Data_Tag_NoNan.Deprived == 1);
Deprived_ContraR = R(find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1)));
Undep_MouseR = R(All_Data_Tag_NoNan.Deprived_Mouse == 0);


SEIpsiR = std(Deprived_IpsiR)/sqrt(length(Deprived_IpsiR));
SEContraR = std(Deprived_ContraR)/sqrt(length(Deprived_ContraR));
SEUndepMR = std(Undep_MouseR)/sqrt(length(Undep_MouseR));

SEIpsi = std(Deprived_Ipsi)/sqrt(length(Deprived_Ipsi));
MeanIpsi = mean(Deprived_Ipsi);
SEContra = std(Deprived_Contra)/sqrt(length(Deprived_Contra));
MeanContra = mean(Deprived_Contra);
SEUndepM = std(Undep_Mouse)/sqrt(length(Undep_Mouse));
MeanUndepM = mean(Undep_Mouse);

 Means = [MeanUndepM MeanIpsi MeanContra];
 SEs = [SEUndepM SEIpsi SEContra];
 SEsR = [SEUndepMR SEIpsiR SEContraR];


 MeansAll = [MeansAll; Means'];
 SEMAll = [SEMAll; SEs'];
 SEM_R_All = [SEM_R_All; SEsR'];

 
 figure()
hold all
% 
bins = 31
 figure(1)
h1 = histogram(Deprived_Contra,bins,'FaceColor',[170,208,55]/255,'Normalization','probability');
edges = h1.BinEdges 
line([0.38 0.38],[0 0.15])
set(gca,'FontSize',12)

figure(2)

h1.BinEdges = edges 
h2 = histogram(Deprived_Ipsi,'FaceColor',[242,101,34]/255,'Normalization','probability');
h2.BinEdges = edges
line([0.38 0.38],[0 0.15])
set(gca,'FontSize',12)


figure(3)
h3 = histogram(Undep_Mouse,'FaceColor',[0.00,0.45,0.74],'Normalization','probability'); 
h3.BinEdges = edges
line([0.38 0.38],[0 0.15])
set(gca,'FontSize',12)


% h1 = histogram(Deprived_Contra,25,'FaceColor',[170,208,55]/255);
% h2 = histogram(Deprived_Ipsi,'FaceColor',[242,101,34]/255);
% h3 = histogram(Undep_Mouse,'FaceColor',[0.00,0.45,0.74]); 

% 

% 
set(gca,'FontSize',12)

fig = gcf; % current figure handle
fig.Color = 'w';


xlabel(strrep(strrep(All_Data_Tag_NoNan.Properties.VariableNames{Var},'_',' '),'all ',''))
% 
ylabel('Proportion')
% legend('Deprived Contra','Deprived Ipsi','Cortex Undeprived Mouse');% [h,p] = kstest2(GroupA,GroupB);

lme.Coefficients
%       pause
%     close
end
%% Crosstab test for relative depth and number of neurites 
%Number of neurites Var = 19 
Var = 19;
Deprived_Ipsi = All_Data_Tag_NoNan{All_Data_Tag_NoNan.Deprived == 1,Var};
Deprived_Contra = All_Data_Tag_NoNan{find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1)),Var};
Undep_Mouse = All_Data_Tag_NoNan{All_Data_Tag_NoNan.Deprived_Mouse == 0,Var};
nUD_bi = sum(Undep_Mouse==2); nUD_Mult = sum(Undep_Mouse>2);
nDI_bi = sum(Deprived_Ipsi==2); nDI_Mult = sum(Deprived_Ipsi>2);
nDC_bi = sum(Deprived_Contra==2); nDC_Mult = sum(Deprived_Contra>2);
       
x1 = [repmat('UD',nUD_bi+nUD_Mult,1); repmat('DI',nDI_bi+nDI_Mult,1); repmat('DC',nDC_bi+nDC_Mult,1) ];
x2 = [repmat(2,nUD_bi,1); repmat(3,nUD_Mult,1); repmat(2,nDI_bi,1); repmat(3,nDI_Mult,1);repmat(2,nDC_bi,1); repmat(3,nDC_Mult,1);];
[tbl,chi2stat,pval] = crosstab(x1,x2)
%posthocs
p = ones(3,1);
stats = cell(3,1);

[h,p(1),stats{1}] = fishertest(tbl([1,2],:))
[h,p(2),stats{2}] = fishertest(tbl([1,3],:))
[h,p(3),stats{3}] = fishertest(tbl([2,3],:))


%%
%Depth Var = 30 
Var = 30;
border = 0.38
Deprived_Ipsi = All_Data_Tag_NoNan{All_Data_Tag_NoNan.Deprived == 1,Var};
Deprived_Contra = All_Data_Tag_NoNan{find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1)),Var};
Undep_Mouse = All_Data_Tag_NoNan{All_Data_Tag_NoNan.Deprived_Mouse == 0,Var};
nUD_bi = sum(Undep_Mouse<border); nUD_Mult = sum(Undep_Mouse>=border);
nDI_bi = sum(Deprived_Ipsi<border); nDI_Mult = sum(Deprived_Ipsi>=border);
nDC_bi = sum(Deprived_Contra<border); nDC_Mult = sum(Deprived_Contra>=border);
       
x1 = [repmat('UD',nUD_bi+nUD_Mult,1); repmat('DI',nDI_bi+nDI_Mult,1); repmat('DC',nDC_bi+nDC_Mult,1) ];
x2 = [repmat(2,nUD_bi,1); repmat(3,nUD_Mult,1); repmat(2,nDI_bi,1); repmat(3,nDI_Mult,1);repmat(2,nDC_bi,1); repmat(3,nDC_Mult,1);];
[tbl,chi2stat,pval,labels] = crosstab(x1,x2)
p = ones(3,1);
stats = cell(3,1);

[h,p(1),stats{1}] = fishertest(tbl([1,2],:))
[h,p(2),stats{2}] = fishertest(tbl([1,3],:))
[h,p(3),stats{3}] = fishertest(tbl([2,3],:))

%% Contra Vs Ipsi With seperation to  biplar
All_Data_Tag_NoNan_Bi = All_Data_Tag_NoNan(All_Data_Tag_NoNan.all_mean_number_of_neurite==2,:);
% SupVec = (All_Data_Tag_NoNan(:,31)>0.3);
% All_Data_Tag_NoNan2 = All_Data_Tag_NoNan(SupVec,:);
MeansAll = [];
SEMAll = [];
Coeff = [];



SEM_R_All = [];
close all
counter = -1;
LastPVal = [];
for Var = [32:43]
  
formula = [All_Data_Tag_NoNan_Bi.Properties.VariableNames{Var},' ~ Cortex_Condition + (1|Side) + (1|Sex) '];

lme = fitlme(All_Data_Tag_NoNan_Bi,formula);


counter = counter + 3 ;
Coeff(counter,:) = double(lme.Coefficients(1,2:end));
Coeff(counter+1,:) = double(lme.Coefficients(2,2:end));
Coeff(counter+2,:) = double(lme.Coefficients(3,2:end));
 LastPVal(counter) =  coefTest(lme,[0 1 -1]);
R = residuals(lme);


Deprived_Ipsi = All_Data_Tag_NoNan_Bi{All_Data_Tag_NoNan_Bi.Deprived == 1,Var};
Deprived_Contra = All_Data_Tag_NoNan_Bi{find((All_Data_Tag_NoNan_Bi.Deprived == 0).*(All_Data_Tag_NoNan_Bi.Deprived_Mouse == 1)),Var};
Undep_Mouse = All_Data_Tag_NoNan_Bi{All_Data_Tag_NoNan_Bi.Deprived_Mouse == 0,Var};

Deprived_IpsiR = R(All_Data_Tag_NoNan_Bi.Deprived == 1);
Deprived_ContraR = R(find((All_Data_Tag_NoNan_Bi.Deprived == 0).*(All_Data_Tag_NoNan_Bi.Deprived_Mouse == 1)));
Undep_MouseR = R(All_Data_Tag_NoNan_Bi.Deprived_Mouse == 0);


SEIpsiR = std(Deprived_IpsiR)/sqrt(length(Deprived_IpsiR));
SEContraR = std(Deprived_ContraR)/sqrt(length(Deprived_ContraR));
SEUndepMR = std(Undep_MouseR)/sqrt(length(Undep_MouseR));

SEIpsi = std(Deprived_Ipsi)/sqrt(length(Deprived_Ipsi));
MeanIpsi = mean(Deprived_Ipsi);
SEContra = std(Deprived_Contra)/sqrt(length(Deprived_Contra));
MeanContra = mean(Deprived_Contra);
SEUndepM = std(Undep_Mouse)/sqrt(length(Undep_Mouse));
MeanUndepM = mean(Undep_Mouse);

 Means = [MeanUndepM MeanIpsi MeanContra];
 SEs = [SEUndepM SEIpsi SEContra];
 SEsR = [SEUndepMR SEIpsiR SEContraR];


 MeansAll = [MeansAll; Means'];
 SEMAll = [SEMAll; SEs'];
 SEM_R_All = [SEM_R_All; SEsR'];

 
 figure()
hold all
% 
h1 = histogram(Deprived_Contra,27,'FaceColor',[170,208,55]/255,'Normalization','probability');
h2 = histogram(Deprived_Ipsi,'FaceColor',[242,101,34]/255,'Normalization','probability');
h3 = histogram(Undep_Mouse,'FaceColor',[0.00,0.45,0.74],'Normalization','probability'); 

% 
set(gca,'FontSize',12)

fig = gcf; % current figure handle
fig.Color = 'w';
edges = h1.BinEdges 

h1.BinEdges = edges 
h2.BinEdges = edges
h3.BinEdges = edges

xlabel(strrep(strrep(All_Data_Tag_NoNan_Bi.Properties.VariableNames{Var},'_',' '),'all ',''))
% 
ylabel('Proportion')
legend('Deprived Contra','Deprived Ipsi','Cortex Undeprived Mouse');% [h,p] = kstest2(GroupA,GroupB);


 lme.Coefficients
%       pause
    close
end


%% Contra Vs Ipsi With seperation to  multipolar 
All_Data_Tag_NoNan_Multi = All_Data_Tag_NoNan(find((All_Data_Tag_NoNan.all_mean_number_of_neurite>2).*(All_Data_Tag_NoNan.all_mean_number_of_neurite<7)),:);
% SupVec = (All_Data_Tag_NoNan(:,31)>0.3);
% All_Data_Tag_NoNan2 = All_Data_Tag_NoNan(SupVec,:);
MeansAll = [];
SEMAll = [];
Coeff = [];



SEM_R_All = [];
close all
counter = -1;
LastPVal = [];
for Var = [32:43]
  
formula = [All_Data_Tag_NoNan_Multi.Properties.VariableNames{Var},' ~ Cortex_Condition + (1|Side) + (1|Sex) '];

lme = fitlme(All_Data_Tag_NoNan_Multi,formula);


counter = counter + 3 ;
Coeff(counter,:) = double(lme.Coefficients(1,2:end));
Coeff(counter+1,:) = double(lme.Coefficients(2,2:end));
Coeff(counter+2,:) = double(lme.Coefficients(3,2:end));
 LastPVal(counter,:) =  coefTest(lme,[0 1 -1]);
R = residuals(lme);


Deprived_Ipsi = All_Data_Tag_NoNan_Multi{All_Data_Tag_NoNan_Multi.Deprived == 1,Var};
Deprived_Contra = All_Data_Tag_NoNan_Multi{find((All_Data_Tag_NoNan_Multi.Deprived == 0).*(All_Data_Tag_NoNan_Multi.Deprived_Mouse == 1)),Var};
Undep_Mouse = All_Data_Tag_NoNan_Multi{All_Data_Tag_NoNan_Multi.Deprived_Mouse == 0,Var};

Deprived_IpsiR = R(All_Data_Tag_NoNan_Multi.Deprived == 1);
Deprived_ContraR = R(find((All_Data_Tag_NoNan_Multi.Deprived == 0).*(All_Data_Tag_NoNan_Multi.Deprived_Mouse == 1)));
Undep_MouseR = R(All_Data_Tag_NoNan_Multi.Deprived_Mouse == 0);


SEIpsiR = std(Deprived_IpsiR)/sqrt(length(Deprived_IpsiR));
SEContraR = std(Deprived_ContraR)/sqrt(length(Deprived_ContraR));
SEUndepMR = std(Undep_MouseR)/sqrt(length(Undep_MouseR));

SEIpsi = std(Deprived_Ipsi)/sqrt(length(Deprived_Ipsi));
MeanIpsi = mean(Deprived_Ipsi);
SEContra = std(Deprived_Contra)/sqrt(length(Deprived_Contra));
MeanContra = mean(Deprived_Contra);
SEUndepM = std(Undep_Mouse)/sqrt(length(Undep_Mouse));
MeanUndepM = mean(Undep_Mouse);

 Means = [MeanUndepM MeanIpsi MeanContra];
 SEs = [SEUndepM SEIpsi SEContra];
 SEsR = [SEUndepMR SEIpsiR SEContraR];

 figure(1)

 MeansAll = [MeansAll; Means'];
 SEMAll = [SEMAll; SEs'];
 SEM_R_All = [SEM_R_All; SEsR'];
errorbar(1:3,Means,SEs);

 
 figure(2)

hold all
% 
h1 = histogram(Deprived_Contra,27,'FaceColor',[170,208,55]/255,'Normalization','probability');
h2 = histogram(Deprived_Ipsi,'FaceColor',[242,101,34]/255,'Normalization','probability');
h3 = histogram(Undep_Mouse,'FaceColor',[0.00,0.45,0.74],'Normalization','probability'); 

% 
set(gca,'FontSize',12)

fig = gcf; % current figure handle
fig.Color = 'w';
edges = h1.BinEdges 

h1.BinEdges = edges 
h2.BinEdges = edges
h3.BinEdges = edges

xlabel(strrep(strrep(All_Data_Tag_NoNan_Multi.Properties.VariableNames{Var},'_',' '),'all ',''))
% 
ylabel('Proportion')
legend('Deprived Contra','Deprived Ipsi','Cortex Undeprived Mouse');% [h,p] = kstest2(GroupA,GroupB);


 lme.Coefficients
%       pause
    close all
end







    
    %% Sholl analysis Multipolar
    figure
    
    ShollRange = 32:43;

    
DepMulti = (All_Data_Tag_NoNan_Multi.Deprived == 1);   
Deprived_Ipsi = [ All_Data_Tag_NoNan_Multi{DepMulti,ShollRange}];
UndepMulti = find((All_Data_Tag_NoNan_Multi.Deprived == 0).*(All_Data_Tag_NoNan_Multi.Deprived_Mouse == 1));
Deprived_Contra = [ All_Data_Tag_NoNan_Multi{UndepMulti,ShollRange}];
UndepMMulti = All_Data_Tag_NoNan_Multi.Deprived_Mouse == 0;
Undep_Mouse = [ All_Data_Tag_NoNan_Multi{UndepMMulti,ShollRange}];

DataAnova = [[Deprived_Ipsi; Deprived_Contra; Undep_Mouse],[ones(length(Deprived_Ipsi),1);ones(length(Deprived_Contra),1)*2;ones(length(Undep_Mouse),1)*3]];

for i = 1:12
    [p(i),tbl,stats] = anova1(DataAnova(:,i),DataAnova(:,end),'off');   
end


meanShollDep = mean(Deprived_Contra);
meanShollUndep = mean(Deprived_Ipsi);
meanShollUndepM = mean(Undep_Mouse);


errShollDep = std(Deprived_Contra);
errShollUndep = std(Deprived_Ipsi);
errShollUndepM = std(Undep_Mouse);

C1 = [170,208,55]/255;
C2 = [242,101,34]/255;
C3 = [0,174,239]/255;
errorbar(20*((1:length(ShollRange))),meanShollDep,errShollDep./sqrt(length(Deprived_Contra)-1));
hold all
errorbar(20*((1:length(ShollRange))),meanShollUndep,errShollUndep./sqrt(length(Deprived_Ipsi)-1));
errorbar(20*((1:length(ShollRange))),meanShollUndepM,errShollUndepM./sqrt(length(Undep_Mouse)-1));

legend('Deprived','Undeprived','UndepM');
xlabel('Distance From Cell Body um')
ylabel('Avg Crossings')
title('deprived Vs undeprived sholl amalysis - Multipolar Neuorns')
%

% [p,tbl,stats] = anova1(hogg);
%% Sholl analysis bipolar
    figure
    
    ShollRange = 32:43;

DepBi = (All_Data_Tag_NoNan_Bi.Deprived == 1);   
Deprived_Ipsi = [All_Data_Tag_NoNan_Bi{DepBi,ShollRange}];
UndepBi = find((All_Data_Tag_NoNan_Bi.Deprived == 0).*(All_Data_Tag_NoNan_Bi.Deprived_Mouse == 1));
Deprived_Contra = [All_Data_Tag_NoNan_Bi{UndepBi,ShollRange}];
UndepMBi = All_Data_Tag_NoNan_Bi.Deprived_Mouse == 0;
Undep_Mouse = [All_Data_Tag_NoNan_Bi{UndepMBi,ShollRange}];


DataAnova = [[Deprived_Ipsi; Deprived_Contra; Undep_Mouse],[ones(length(Deprived_Ipsi),1);ones(length(Deprived_Contra),1)*2;ones(length(Undep_Mouse),1)*3]];

for i = 1:12
    [p(i),tbl,stats] = anova1(DataAnova(:,i),DataAnova(:,end),'off');   
end


meanShollDep = mean(Deprived_Contra);
meanShollUndep = mean(Deprived_Ipsi);
meanShollUndepM = mean(Undep_Mouse);


errShollDep = std(Deprived_Contra);
errShollUndep = std(Deprived_Ipsi);
errShollUndepM = std(Undep_Mouse);

C1 = [170,208,55]/255;
C2 = [242,101,34]/255;
C3 = [0,174,239]/255;
errorbar(20*((1:length(ShollRange))),meanShollDep,errShollDep./sqrt(length(Deprived_Contra)-1));
hold all
errorbar(20*((1:length(ShollRange))),meanShollUndep,errShollUndep./sqrt(length(Deprived_Ipsi)-1));
errorbar(20*((1:length(ShollRange))),meanShollUndepM,errShollUndepM./sqrt(length(Undep_Mouse)-1));

legend('Deprived','Undeprived','UndepM');
xlabel('Distance From Cell Body um')
ylabel('Avg Crossings')
title('deprived Vs undeprived sholl amalysis - Bipolar Neuorns')
%



%% Sholl analysis All
    figure
    
    ShollRange = 32:43;

    
Dep = (All_Data_Tag_NoNan.Deprived == 1);   
Deprived_Ipsi = [All_Data_Tag_NoNan{Dep,ShollRange}];
Undep = find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1));
Deprived_Contra = [All_Data_Tag_NoNan{Undep,ShollRange}];
UndepM = All_Data_Tag_NoNan.Deprived_Mouse == 0;
Undep_Mouse = [All_Data_Tag_NoNan{UndepM,ShollRange}];


%
DataAnova = [[Deprived_Ipsi; Deprived_Contra; Undep_Mouse],[ones(length(Deprived_Ipsi),1);ones(length(Deprived_Contra),1)*2;ones(length(Undep_Mouse),1)*3]];

for i = 1:12
    [p(i),tbl,stats] = anova1(DataAnova(:,i),DataAnova(:,end),'off');
     
end



meanShollDep = mean(Deprived_Contra);
meanShollUndep = mean(Deprived_Ipsi);
meanShollUndepM = mean(Undep_Mouse);


errShollDep = std(Deprived_Contra);
errShollUndep = std(Deprived_Ipsi);
errShollUndepM = std(Undep_Mouse);

C1 = [170,208,55]/255;
C2 = [242,101,34]/255;
C3 = [0,174,239]/255;
errorbar(20*((1:length(ShollRange))),meanShollDep,errShollDep./sqrt(length(Deprived_Contra)-1));
hold all
errorbar(20*((1:length(ShollRange))),meanShollUndep,errShollUndep./sqrt(length(Deprived_Ipsi)-1));
errorbar(20*((1:length(ShollRange))),meanShollUndepM,errShollUndepM./sqrt(length(Undep_Mouse)-1));

legend('Deprived','Undeprived','UndepM');
xlabel('Distance From Cell Body um')
ylabel('Avg Crossings')
title('deprived Vs undeprived sholl amalysis - All Neuorns')
%
%%
SelectedF = [2:43 53];
var = 29
names = All_Data_Tag_NoNan.Properties.VariableNames(SelectedF)
Dep = (All_Data_Tag_NoNan.Deprived == 1);   
Deprived_Ipsi = [All_Data_Tag_NoNan{Dep,SelectedF}];
Undep = find((All_Data_Tag_NoNan.Deprived == 0).*(All_Data_Tag_NoNan.Deprived_Mouse == 1));
Deprived_Contra = [All_Data_Tag_NoNan{Undep,SelectedF}];
UndepM = All_Data_Tag_NoNan.Deprived_Mouse == 0;
Undep_Mouse = [All_Data_Tag_NoNan{UndepM,SelectedF}];
[Corr P] = corrcoef(Deprived_Ipsi);
DepthIpsi = Corr(:,var);
[Corr P] = corrcoef(Deprived_Contra);
DepthContra = Corr(:,var);
[Corr P] = corrcoef(Undep_Mouse);
DepthUndepM = Corr(:,var);
plot(DepthContra,'*')
hold all 
plot(DepthIpsi,'*')
plot(DepthUndepM,'*')
legend('Deprived','Undeprived','UndepM');




%% tsne differintiated 
%% tsne bipolar
SelectedF = [2:43 53];
Y = tsne(zscore(All_Data_Tag_NoNan_Bi{:,SelectedF}));


%%
clc
close all
counter = 0;
clear Tags
figure(1)   
for Var = [2:43 53]
    counter = counter+1;
    for i = 1:length(Y)   
    %             Tags(i) = round((All_Data_Tag_NoNan(i,Var))*10);
%                     Tags(i) = (Names{i,2*D}<9);
%                        Tags(i) = round(10*(RelevantGroup{D}{i,Var})./quantile(RelevantGroup{D}{:,Var},0.95));
                         Tags(i) =All_Data_Tag_NoNan_Bi{i,Var};
%     if All_Data_Tag(i,end)
%         if All_Data_Tag(i,end-1)
%             Tags{i} = 'Female ';
%         else

%             Tags{i} = 'Female ';
%         end
%     else
%          if All_Data_Tag(i,end-1)
%             Tags{i} = 'Male ';
%         else
%             Tags{i} = 'Male ';
%          end
%     end
    end
    if mod(Tags(1),1)~=0 
        Tags = Tags - min(Tags) +1;
        Tags = round(rescale(Tags,1,10));
    else 
        Tags = round(Tags);
    end
map = log2(parula(length(unique(Tags)))+1);
% map = parula(length(unique(Tags)));
% subplot(2,6,counter)
gscatter(Y(:,1),Y(:,2),Tags',map,'.',10);
title([strrep(strrep(All_Data_Tag_NoNan_Bi.Properties.VariableNames{Var},'_',' '),'all ','')])
xlabel('t-SNE, PC1');
ylabel('t-SNE, PC2');
Var

pause
end

%% tsne bipolar
SelectedF = [2:43 53];

OnlyNumeral = All_Data_Tag_NoNan_Multi{:,SelectedF};
[Corr P] = corrcoeff(OnlyNumeral);
Y = tsne(zscore(All_Data_Tag_NoNan_Multi{:,SelectedF}));


%%
clc
close all
counter = 0;
clear Tags
figure(1)   
for Var = [2:43 53]
    counter = counter+1;
    for i = 1:length(Y)   
    %             Tags(i) = round((All_Data_Tag_NoNan(i,Var))*10);
%                     Tags(i) = (Names{i,2*D}<9);
%                        Tags(i) = round(10*(RelevantGroup{D}{i,Var})./quantile(RelevantGroup{D}{:,Var},0.95));
                         Tags(i) =All_Data_Tag_NoNan_Multi{i,Var};
%     if All_Data_Tag(i,end)
%         if All_Data_Tag(i,end-1)
%             Tags{i} = 'Female ';
%         else

%             Tags{i} = 'Female ';
%         end
%     else
%          if All_Data_Tag(i,end-1)
%             Tags{i} = 'Male ';
%         else
%             Tags{i} = 'Male ';
%          end
%     end
    end
    if mod(Tags(1),1)~=0 
        Tags = Tags - min(Tags) +1;
        Tags = round(rescale(Tags,1,10));
    else 
        Tags = round(Tags);
    end
map = log2(parula(length(unique(Tags)))+1);
% map = parula(length(unique(Tags)));
% subplot(2,6,counter)
gscatter(Y(:,1),Y(:,2),Tags',map,'.',10);
title([strrep(strrep(All_Data_Tag_NoNan_Multi.Properties.VariableNames{Var},'_',' '),'all ','')])
xlabel('t-SNE, PC1');
ylabel('t-SNE, PC2');
Var

pause
end