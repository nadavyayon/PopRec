%% Find all somata coordinates 
clc 
clear 
close all
 
Directories = { 
'G:\iDISCO_Imaging\SingleCells01'; %SingleCells01 - 
'G:\iDISCO_Imaging\SingleCells02'; %SingleCells02 - 
'G:\iDISCO_Imaging\SingleCells03'; %SingleCells03 - 
'G:\iDISCO_Imaging\SingleCells04'; %SingleCells04 - 
'G:\iDISCO_Imaging\SingleCells05'; %SingleCells05 - 
'G:\iDISCO_Imaging\SingleCells06'; %SingleCells06 - 
'G:\iDISCO_Imaging\SingleCells07'; %SingleCells07 - 
'G:\iDISCO_Imaging\SingleCells08'; %SingleCells08 - 
'G:\iDISCO_Imaging\SingleCells09'; %SingleCells09 - 
'G:\iDISCO_Imaging\SingleCells10'; %SingleCells10 - 
'G:\iDISCO_Imaging\SingleCells11'; %SingleCells11 - 
'G:\iDISCO_Imaging\SingleCells12'; %SingleCells12 - 
'G:\iDISCO_Imaging\SingleCells13'; %SingleCells13 - 
'G:\iDISCO_Imaging\SingleCells14'; %SingleCells14 -
}

%%
SurfData = SomaDepthIncode([Directories{d},'\NormalizedBackground\SupportImages']);

%% Meausre Surface 
i = 0;
while i == 0 
    SurfDatatminus1 = SurfData;
%         SurfData = SurfDatatminus1;

    close all
    T = clusterdata(SurfData,2);
    SurfData1 = SurfData(find(T==1),:);
    SurfData2 = SurfData(find(T==2),:);
    figure
    hold
    plot3(SurfData1(:,1),SurfData1(:,2),SurfData1(:,3),'.r')
    plot3(SurfData2(:,1),SurfData2(:,2),SurfData2(:,3),'.g')
    legend('Surf1','Surf2');
%      Decision = input('select correct surface (1/2)');    
     Decision = 2;
        if Decision == 1
            SurfData = SurfData1;
        end

        if Decision == 2
            SurfData = SurfData2;
        end

      i = input('Is it good enough? (0-no, 1-yes)');  
      if i == 0
          for ii = 1:length(Toexclude)
           index = find(((SurfData(:,1) == Toexclude(ii,1)) + (SurfData(:,2) == Toexclude(ii,2)) + (SurfData(:,3) == Toexclude(ii,3))==3))
           SurfData(index,:) = [0,0,0];
          end
      end

end

%% Save data
cd(Directories{d})
save('BottomSurfData','SurfData');
% save('Depth','Depth');


%% measuere eucledian distance  To top
 for d = 1:length(Directories)
 clear Depth
     
     close all
cd(Directories{d})

load SurfData;
load([Directories{d},'\NormalizedBackground\Shaved\COMCoordinates']);
figure
CellOrientationVec = [0 0 0];
SurfClosePointmeanVecTemp = [0 0 0];
for i = 1:length(COMCoordinates)
   [SortDepth SortInd] = sort(pdist2(COMCoordinates(i,[2,1,3]),SurfData)'); 
   Depth(i)  = mean(SortDepth(1:10));
   SurfClosePointmeanVecTemp = mean(SurfData(SortInd(1:10),:));
   CellOrientationVec(i,:) =  SurfClosePointmeanVecTemp - COMCoordinates(i,[2,1,3]);
%    CellOrientationUnitVec(i,:) = CellOrientationUnitVec(i,:)./norm(CellOrientationUnitVec(i,:));
end

hold
% quiver3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),CellOrientationVec(:,1),CellOrientationVec(:,2),CellOrientationVec(:,3),2);
plot3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),'.r');
plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.k');
axis('equal')
CellOrientationVecUnit = CellOrientationVec./repmat(vecnorm(CellOrientationVec')',1,3);


figure
histfit(Depth,35,'kernel');
% Save data
cd(Directories{d})
save('Depth','Depth');
save('CellOrientationVecUnit','CellOrientationVecUnit');
 end

%% measuere eucledian distance  To bottom
close all
clear DepthBottom
for d = 1:length(Directories);
cd(Directories{d})

load BottomSurfData;
load([Directories{d},'\NormalizedBackground\Shaved\COMCoordinates']);
figure
CellOrientationVec = [0 0 0];
SurfClosePointmeanVecTemp = [0 0 0];
for i = 1:length(COMCoordinates)
   [SortDepth SortInd] = sort(pdist2(COMCoordinates(i,[2,1,3]),SurfData)'); 
   DepthBottom(i)  = mean(SortDepth(1:10));
   SurfClosePointmeanVecTemp = mean(SurfData(SortInd(1:10),:));
   CellOrientationVec(i,:) =  SurfClosePointmeanVecTemp - COMCoordinates(i,[2,1,3]);
%    CellOrientationUnitVec(i,:) = CellOrientationUnitVec(i,:)./norm(CellOrientationUnitVec(i,:));
end

hold
% quiver3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),CellOrientationVec(:,1),CellOrientationVec(:,2),CellOrientationVec(:,3),2);
plot3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),'.r');
plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.k');
axis('equal')
CellOrientationVecUnit = CellOrientationVec./repmat(vecnorm(CellOrientationVec')',1,3);


figure(d)
histfit(DepthBottom,35,'kernel');
% Save data
cd(Directories{d})
save('DepthBottom','DepthBottom');
% save('CellOrientationVecUnit','CellOrientationVecUnit');
 end

%% find in/out barrel and filter size 
%% Test load Barrel Vertices 

BarrelDirectories = {
 %SingleCells01 - 
 'G:\iDISCO_Imaging\AutoFlou01';
 %SingleCells02 - 
 'G:\iDISCO_Imaging\AutoFlou02';
 %SingleCells03 - 
 'G:\iDISCO_Imaging\AutoFlou03';
 %SingleCells04 - 
 'G:\iDISCO_Imaging\AutoFlou04';
 %SingleCells05 - 
 'G:\iDISCO_Imaging\AutoFlou05';
 %SingleCells06 - 
 'G:\iDISCO_Imaging\AutoFlou06';
 %SingleCells07 - 
 'G:\iDISCO_Imaging\AutoFlou07';
 %SingleCells08 - 
 'G:\iDISCO_Imaging\AutoFlou08';
 %SingleCells09 - 
 'G:\iDISCO_Imaging\AutoFlou09';
 %SingleCells10 - 
 'G:\iDISCO_Imaging\AutoFlou10';
 %SingleCells11 - 
 'G:\iDISCO_Imaging\AutoFlou11';
 %SingleCells12 - 
 'G:\iDISCO_Imaging\AutoFlou12';
 %SingleCells13 - 
 'G:\iDISCO_Imaging\AutoFlou13';
 %SingleCells14 - 
 'G:\iDISCO_Imaging\AutoFlou14';
}
for i = 1:length(BarrelDirectories)
    BarrelPoints{i} = 'DS_xyz_4.points';
end


%R is 0 L is 1
Sides(1) = 0;
Sides(2) = 1;
Sides(3) = 0;
Sides(4) = 1;
Sides(5) = 0;
Sides(6) = 1;
Sides(7) = 0;
Sides(8) = 1;
Sides(9) = 0;
Sides(10) = 1;
Sides(11) = 0;
Sides(12) = 1;
Sides(13) = 0;
Sides(14) = 1;

% 0 is male 1 is female 
Gender(1) = 0;
Gender(2) = 0;
Gender(3) = 0;
Gender(4) = 0;
Gender(5) = 1;
Gender(6) = 1;
Gender(7) = 1;
Gender(8) = 1;
Gender(9) = 1;
Gender(10) = 1;
Gender(11) = 0;
Gender(12) = 0;
Gender(13) = 1;
Gender(14) = 1;

clear P
coordinatematching = [4 0 0; 0 4 0; 0 0 4]; %compensate for downsampling autoFlu
for i = 1:length(BarrelDirectories) 
    cd(BarrelDirectories{i})
    P{i} = importPoints3(BarrelPoints{i});
    BarrelShapes{i} =  alphaShape(P{i}*coordinatematching,inf);
    subplot(3,5,i)
    plot(BarrelShapes{i})
    title(i)
    
    figure(2)
    ExpandedBarrelShapes{i} = ExpandBarrelShapes(BarrelShapes{i},1.1);
    plot(ExpandedBarrelShapes{i})
    title(i)
end

%% load all DepthData 
close all

Depths = cell(1,length(Directories));
RelativeDepths = cell(1,length(Directories));

BottomDepths = cell(1,length(Directories));

COMs = cell(1,length(Directories));
Diamses = cell(1,length(Directories));
CellOrientationVecUnits = cell(1,length(Directories));
cellInfos{d} = cell(1,length(Directories));
MinDiams = ones(length(Directories,1))*11;
MaxDiams = ones(length(Directories,1))*18;
for d = 1:length(Directories)
    clear Depth DepthBottom
    cd([Directories{d},'\NormalizedBackground\Shaved\8bit\8bitDend\SingleCells',num2str(d,'%02.f')]);
    cellInfoTemp = dir('*.tif');
    cd(Directories{d})
    load('Depth');
    load('DepthBottom');
    load CellOrientationVecUnit
    cd([Directories{d},'\NormalizedBackground\Shaved']);
    load('SomaDiams');
    load('COMCoordinates');
    relevantSomataTemp = find((Diams>=MinDiams(d)).*(Diams<=MaxDiams(d)));    
    Depths{d} = (Depth(relevantSomataTemp));
    RelativeDepths{d} = (Depth(relevantSomataTemp)./(Depth(relevantSomataTemp)+DepthBottom(relevantSomataTemp)));
    COMs{d} = COMCoordinates(relevantSomataTemp,:);
    Diamses{d} = Diams(relevantSomataTemp);
    CellOrientationVecUnits{d} = CellOrientationVecUnit(relevantSomataTemp,:);
    cellInfos{d} = cellInfoTemp(relevantSomataTemp,:);
    subplot(5,3,d)
    plot(ExpandedBarrelShapes{d})
    hold
    plot3(COMs{d}(:,1),COMs{d}(:,2),COMs{d}(:,3),'.')
    title(d)

 
end
%% Visualise 
 daspect([1,1,.3]);axis tight;
 OptionZ.FrameRate=24;OptionZ.Duration=10;OptionZ.Periodic=true;
CaptureFigVid([-20,10;-110,10;-190,80;-290,10;-380,10],'WellMadeVid',OptionZ)

%% Find only cells in barrels 
MegaTable = [];
for i = 1:length(Directories)
    BarrelVolumes(i) = volume(BarrelShapes{i});
end
RelativeBarrelVolumes = BarrelVolumes./max(BarrelVolumes);

for i = 1:length(Directories)  
    IsInBarrelTemp = table([ones(length(Depths{i}),1).*i],[{cellInfos{i}.name}'],[inShape(ExpandedBarrelShapes{i},COMs{i}(:,1),COMs{i}(:,2),COMs{i}(:,3))],...
        [Depths{i}'],[RelativeDepths{i}'],[CellOrientationVecUnits{i}(:,1),CellOrientationVecUnits{i}(:,2),CellOrientationVecUnits{i}(:,3)],...
        [COMs{i}(:,1),COMs{i}(:,2),COMs{i}(:,3)],[ones(length(Depths{i}),1).*Gender(d)],'VariableNames',{['SampleNumber'],['CellNames'],['IsInBarrel'],['Cortical_Depth'],['Relative_Cortical_Depth'],['CellOrientationVecUnit'],['COMxyz'],['Gender']});
    BarrelVolumes = volume(BarrelShapes{i});  
    BarrelVolumes(i)])
    MegaTable = [MegaTable; IsInBarrelTemp];
    SampleVariables{i} = IsInBarrelTemp(IsInBarrelTemp.IsInBarrel,:);
end


%% match feature data with other data
for d = 1:length(Directories)
   
    SWCDirectory = ['G:\iDISCO_Imaging\NewLS\WT_Batch_24_3_19\GenderDifferemces\SingleCells',sprintf('%02d',d),'\SWC\Sorted\RelevantCells\GoodCells'];
    cd(SWCDirectory);
    FeatureTable{d} = readtable(['BestCellsCoord_SingleCells',sprintf('%02d',d),'.csv']);
    FeatureNamesTemp = cellfun(@(x) x(6:8),FeatureTable{d}.name,'UniformOutput',false);
    FeatureNamesTemp = cellfun(@str2num,FeatureNamesTemp,'UniformOutput',false);
    FeatureNumTemp = cell2mat(FeatureNamesTemp);
    
    OtherVariablesNamestemp = cellfun(@(x) x(6:8),SampleVariables{d}.CellNames,'UniformOutput',false);
    OtherVariablesNamestemp = cellfun(@str2num,OtherVariablesNamestemp,'UniformOutput',false);
    OtherVariablesNumTemp = cell2mat(OtherVariablesNamestemp);
    CellIndexInFeatureTable = []
%     NewFeatureTableWithBarrels{d} = [FeatureTable{d}(1,:) SampleVariables{d}(1,:)];
%     NewFeatureTableWithBarrels{d}(1,:) = [];
    counter = 0;
    for Cell = 1:length(OtherVariablesNumTemp) 
        CellIndexInFeatureTable = find(OtherVariablesNumTemp(Cell) == FeatureNumTemp);
        if ~isempty(CellIndexInFeatureTable);
            counter = counter + 1;
            NewFeatureTableInBarrels{d}(counter,:) =  [FeatureTable{d}(CellIndexInFeatureTable,1:end-1) SampleVariables{d}(Cell,:)];
        end
    end
    
     writetable(NewFeatureTableInBarrels{1,d},['OnlyCellsInBarrelsAllData',sprintf('%02d',d),'.csv']);
end

%% Aux Functions %%%%%%%%%%%%%%%%%%%%%%
function SurfData = SomaDepthIncode(SupportFolder)
    cd(SupportFolder);
    Info = dir('*Tissue*');
    close all
    cmap = colormap(jet(length(Info)))
    x = [];
    y = [];
    z = [];

    for i = 1:5:length(Info) 
         i
         im = imread(Info(i).name);
%          imagesc(im);
         im = imfill(im,'holes');
         [xtemp ,ytemp] = find(edge(im));

         x = [x; xtemp(1:10:end)];
         y = [y; ytemp(1:10:end)];
         z = [z; ones(length(xtemp(1:10:end,1)),1).*i];
    %      T = clusterdata(xtemp(1:10:end),ytemp(1:10:end),2);
    %      plot(
    end
          Data = single([x y z]);
          DownData = Data(1:10:end,:);
          T = clusterdata(DownData,2);
          SurfData1 = DownData(find(T==1),:);
          SurfData2 = DownData(find(T==2),:);
          figure
          hold
          plot3(SurfData1(:,1),SurfData1(:,2),SurfData1(:,3),'.r')
          plot3(SurfData2(:,1),SurfData2(:,2),SurfData2(:,3),'.g')
          legend('Surf1','Surf2');
    Decision = input('select correct surface (1/2)');      
    if Decision == 1
        SurfData = SurfData1;
    end

    if Decision == 2
        SurfData = SurfData2;
    end

end



