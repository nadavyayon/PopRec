%% Find all somata coordinates 
clc 
clear 
close all
MotherDir = 'E:\PROJECTS\EMCU\4thWhiskerDeprived\Cropped_647';
Directories = dir(MotherDir); Directories = Directories(3:end,:);  Directories = Directories([Directories.isdir]',:);
%% Top
for d = 1:length(Directories);

%
SurfData = SomaDepthIncode([Directories(d).folder,filesep,Directories(d).name,filesep,'SupportImages'],10,20);

% Meausre Surface 
i = 0;
while i == 0 
    SurfDatatminus1 = SurfData;
%         SurfData = SurfDatatminus1;

    close all
    T = clusterdata(SurfData,2);
    SurfData1 = SurfData(find(T==1),:);
    SurfData2 = SurfData(find(T==2),:);
%     [~, BiggerSurf] = max([length(SurfData1),length(SurfData2)]);
%     SurfData1 = SurfData(find(T==BiggerSurf),:);

    figure
    plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.r')

    legend('Surf1');
    i = input('Is it good enough? (no: label errors (varname = e) and type 0, yes: 1 - finish)');      Decision = 2;
        if i == 0
            for ii = 1:length(e)
                index = find(((SurfData(:,1) == e(ii,1)) + (SurfData(:,2) == e(ii,2)) + (SurfData(:,3) == e(ii,3))~=3));
                SurfData  = SurfData(index,:);
            end
        end


end

% Save data
cd([Directories(d).folder,filesep,Directories(d).name,filesep])
save('TopSurfData','SurfData');
% save('Depth','Depth');
end
%% Bottom
for d = 1:length(Directories);

%
SurfData = SomaDepthIncode([Directories(d).folder,filesep,Directories(d).name,filesep,'SupportImages'],10,20);

% Meausre Surface 
i = 0;
while i == 0 
    SurfDatatminus1 = SurfData;
%         SurfData = SurfDatatminus1;

    close all
    T = clusterdata(SurfData,2);
    SurfData1 = SurfData(find(T==1),:);
    SurfData2 = SurfData(find(T==2),:);
%     [~, BiggerSurf] = max([length(SurfData1),length(SurfData2)]);
%     SurfData1 = SurfData(find(T==BiggerSurf),:);

    figure
    plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.r')

    legend('Surf1');
    i = input('Is it good enough? (no: label errors (varname = e) and type 0, yes: 1 - finish)');      Decision = 2;
        if i == 0
            for ii = 1:length(e)
                index = find(((SurfData(:,1) == e(ii,1)) + (SurfData(:,2) == e(ii,2)) + (SurfData(:,3) == e(ii,3))~=3));
                SurfData  = SurfData(index,:);
            end
        end


end

% Save data
cd([Directories(d).folder,filesep,Directories(d).name,filesep])
save('BottomSurfData','SurfData');
% save('Depth','Depth');
end

%% measuere eucledian distance  To top
PathTOCOM = 'E:\PROJECTS\EMCU\4thWhiskerDeprived\SomaToCube\SomaToCoubeOutput\Cubes_Norm2All_';
 for d = 1:length(Directories)
 clear Depth SurfData
     
     close all
cd([Directories(d).folder,filesep,Directories(d).name,filesep])
load TopSurfData.mat;

load([PathTOCOM,Directories(d).name,'\COMCoordinates.mat']);
subplot(1,2,1)
CellOrientationVec = [0 0 0];
SurfClosePointmeanVecTemp = [0 0 0];
for i = 1:length(COMCoordinates)
   [SortDepth SortInd] = sort(pdist2(COMCoordinates(i,[2,1,3]),SurfData)'); 
   Depth(i)  = mean(SortDepth(1:10));
   SurfClosePointmeanVecTemp = mean(SurfData(SortInd(1:10),:));
   CellOrientationVec(i,:) =  SurfClosePointmeanVecTemp - COMCoordinates(i,[2,1,3]);
%    CellOrientationUnitVec(i,:) = CellOrientationUnitVec(i,:)./norm(CellOrientationUnitVec(i,:));
end


hold
% quiver3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),CellOrientationVec(:,1),CellOrientationVec(:,2),CellOrientationVec(:,3),2);
plot3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),'.r');
plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.k');
axis('equal')
CellOrientationVecUnit = CellOrientationVec./repmat(vecnorm(CellOrientationVec')',1,3);


subplot(1,2,2)
histfit(Depth,35,'kernel');
axis([0 1000 0 100])
% Save data
save('Depth','Depth');
save('CellOrientationVecUnit','CellOrientationVecUnit');
pause;
 end

%% measuere eucledian distance  To bottom

PathTOCOM = 'E:\PROJECTS\EMCU\4thWhiskerDeprived\SomaToCube\SomaToCoubeOutput\Cubes_Norm2All_';
 for d = 1:length(Directories)
 clear Depth SurfData
     
     close all
cd([Directories(d).folder,filesep,Directories(d).name,filesep])
load BottomSurfData.mat;

load([PathTOCOM,Directories(d).name,'\COMCoordinates.mat']);
subplot(1,2,1)
CellOrientationVec = [0 0 0];
SurfClosePointmeanVecTemp = [0 0 0];
for i = 1:length(COMCoordinates)
   [SortDepth SortInd] = sort(pdist2(COMCoordinates(i,[2,1,3]),SurfData)'); 
   Depth(i)  = mean(SortDepth(1:10));
   SurfClosePointmeanVecTemp = mean(SurfData(SortInd(1:10),:));
   CellOrientationVec(i,:) =  SurfClosePointmeanVecTemp - COMCoordinates(i,[2,1,3]);
%    CellOrientationUnitVec(i,:) = CellOrientationUnitVec(i,:)./norm(CellOrientationUnitVec(i,:));
end


hold
% quiver3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),CellOrientationVec(:,1),CellOrientationVec(:,2),CellOrientationVec(:,3),2);
plot3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),'.r');
plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.k');
axis('equal')
CellOrientationVecUnit = CellOrientationVec./repmat(vecnorm(CellOrientationVec')',1,3);


subplot(1,2,2)
histfit(Depth,35,'kernel');
axis([0 1000 0 100])
% Save data
save('DepthBottom','Depth');
pause;
 end
 
 
%% find in/out barrel and filter size 
%% Test load Barrel Vertices 

clear BarrelPoints
for i = 1:length(Directories)
    BarrelPoints{i} = ['E:\PROJECTS\EMCU\4thWhiskerDeprived\DS_Cropped_488\DS_',Directories(i).name,'\NormalizedBackground\Norm2All\Barrel_Coordinates_025.points'];
end

clear P
coordinatematching = [4 0 0; 0 4 0; 0 0 4]; %compensate for downsampling autoFlu
for i = 1:length(BarrelPoints) 
    
    P{i} = importPoints3(BarrelPoints{i});
    BarrelShapes{i} =  alphaShape(P{i}*coordinatematching,inf);
    subplot(4,6,i)
    plot(BarrelShapes{i})
    title(i)
    
    ExpandedBarrelShapes{i} = ExpandBarrelShapes(BarrelShapes{i},1.3);
    plot(ExpandedBarrelShapes{i})
    title(i)
end
%% Metadata from autoflourescence inspection
%R is 0 L is 1 % updated 11.6.21
Sides(1) = 1; 
Sides(2) = 0;
Sides(3) = 0;
Sides(4) = 1;
Sides(5) = 1;
Sides(6) = 0;
Sides(7) = 1;
Sides(8) = 0;
Sides(9) = 0;
Sides(10) = 1;
Sides(11) = 1;
Sides(12) = 0;
Sides(13) = 0;
Sides(14) = 1;
Sides(15) = 0;
Sides(16) = 1;
Sides(17) = 1;
Sides(18) = 0;
Sides(19) = 0;
Sides(20) = 1;
Sides(21) = 1;
Sides(22) = 0;
Sides(23) = 0;
Sides(24) = 1;

% 0 is male 1 is female 
Gender(1) = 1;
Gender(2) = 1;
Gender(3) = 1;
Gender(4) = 1;
Gender(5) = 0;
Gender(6) = 0;
Gender(7) = 0;
Gender(8) = 0;
Gender(9) = 0;
Gender(10) = 0;
Gender(11) = 0;
Gender(12) = 0;
Gender(13) = 1;
Gender(14) = 1;
Gender(15) = 0;
Gender(16) = 0;
Gender(17) = 1;
Gender(18) = 1;
Gender(19) = 1;
Gender(20) = 1;
Gender(21) = 0;
Gender(22) = 0;
Gender(23) = 0;
Gender(24) = 0;




%% load all DepthData 
PathTOCOM = 'E:\PROJECTS\EMCU\4thWhiskerDeprived\SomaToCube\SomaToCoubeOutput\Cubes_Norm2All_';

close all

Depths = cell(1,length(Directories));
RelativeDepths = cell(1,length(Directories));

BottomDepths = cell(1,length(Directories));

COMs = cell(1,length(Directories));
Diamses = cell(1,length(Directories));
CellOrientationVecUnits = cell(1,length(Directories));
cellInfos = cell(1,length(Directories));
MinDiams = ones(length(Directories))*5;
MaxDiams = ones(length(Directories))*25;
for d = 1:length(Directories)
    clear Depth DepthBottom
    
    cd([PathTOCOM,Directories(d).name]); % to single cells folder 
    cellInfoTemp = dir('*.tif');
    load('SomaStats');
    load('COMCoordinates');
    
    cd([Directories(d).folder,filesep,Directories(d).name,filesep]) % from image stack folder
    load('Depth');
    DepthTop = Depth;
    load('DepthBottom');
    DepthBottom = Depth;
    load CellOrientationVecUnit
    
    relevantSomataTemp = find((SomaStats.EquivDiameter>=MinDiams(d)).*(SomaStats.EquivDiameter<=MaxDiams(d)));    
    Depths{d} = (DepthTop(relevantSomataTemp));
    RelativeDepths{d} = (DepthTop(relevantSomataTemp)./(DepthTop(relevantSomataTemp)+DepthBottom(relevantSomataTemp)));
    COMs{d} = COMCoordinates(relevantSomataTemp,:);
    Diamses{d} = SomaStats.EquivDiameter(relevantSomataTemp);
    CellOrientationVecUnits{d} = CellOrientationVecUnit(relevantSomataTemp,:);
    cellInfos{d} = cellInfoTemp(relevantSomataTemp,:);
    subplot(6,4,d)
    plot(ExpandedBarrelShapes{d})
    hold
    plot3(COMs{d}(:,1),COMs{d}(:,2),COMs{d}(:,3),'.')
    title(d)

 
end
%% Visualise 
 daspect([1,1,.3]);axis tight;
 OptionZ.FrameRate=24;OptionZ.Duration=10;OptionZ.Periodic=true;
CaptureFigVid([-20,10;-110,10;-190,80;-290,10;-380,10],'WellMadeVid',OptionZ)

%% Find only cells in barrels 
MegaTable = [];
for i = 1:length(Directories)
    BarrelVolumes(i) = volume(BarrelShapes{i});
end
RelativeBarrelVolumes = BarrelVolumes./max(BarrelVolumes);

for i = 1:length(Directories)  
    IsInBarrelTemp = table([ones(length(Depths{i}),1).*i],[{cellInfos{i}.name}'],[inShape(ExpandedBarrelShapes{i},COMs{i}(:,1),COMs{i}(:,2),COMs{i}(:,3))],...
        [Depths{i}'],[RelativeDepths{i}'],[CellOrientationVecUnits{i}(:,1),CellOrientationVecUnits{i}(:,2),CellOrientationVecUnits{i}(:,3)],...
        [COMs{i}(:,1),COMs{i}(:,2),COMs{i}(:,3)],[ones(length(Depths{i}),1).*Gender(d)],'VariableNames',{['SampleNumber'],['CellNames'],['IsInBarrel'],['Cortical_Depth'],['Relative_Cortical_Depth'],['CellOrientationVecUnit'],['COMxyz'],['Gender']});
    BarrelVolumes = volume(BarrelShapes{i});  
    MegaTable = [MegaTable; IsInBarrelTemp];
    SampleVariables{i} = IsInBarrelTemp(IsInBarrelTemp.IsInBarrel,:);
end


%% match feature data with other data
cd E:\PROJECTS\EMCU\4thWhiskerDeprived\SomaToCube
load FeaturesPassThresholdCellsAllwSholl.mat
for d = 1:length(Directories)
   
    
    FeatureTable{d} = FeaturesPassThresholdCellsAllwSholl{d};
%     Fix Sholl data
    ShollTable = array2table(zeros(height(FeatureTable{d}),15));
    for i = 1:15
        ShollTable.Properties.VariableNames{i} = ['IndividialSholl_',num2str(i)];
    end
    for i = 1:height(ShollTable)
        ShollTable{i,:} = FeatureTable{d}.('sholl'){i};
    end
    FeatureTable{d} = FeatureTable{d}(:,not(strcmp(FeatureTable{d}.Properties.VariableNames,{'sholl'}))); % remove sholl
    FeatureTable{d} = FeatureTable{d}(:,not(strcmp(FeatureTable{d}.Properties.VariableNames,{'sholl_frequency'}))); % remove sholl frequency 

    FeatureTable{d} =  [FeatureTable{d} ShollTable]; % Return Correctec Sholl data
    FeatureNamesTemp = cellfun(@(x) x(6:8),FeatureTable{d}.name,'UniformOutput',false);
    FeatureNamesTemp = cellfun(@str2num,FeatureNamesTemp,'UniformOutput',false);
    FeatureNumTemp = cell2mat(FeatureNamesTemp);
    
    OtherVariablesNamestemp = cellfun(@(x) x(6:8),SampleVariables{d}.CellNames,'UniformOutput',false);
    OtherVariablesNamestemp = cellfun(@str2num,OtherVariablesNamestemp,'UniformOutput',false);
    OtherVariablesNumTemp = cell2mat(OtherVariablesNamestemp);
    CellIndexInFeatureTable = []

    counter = 0;
    for Cell = 1:length(OtherVariablesNumTemp) 
        CellIndexInFeatureTable = find(OtherVariablesNumTemp(Cell) == FeatureNumTemp);
        if ~isempty(CellIndexInFeatureTable);
            counter = counter + 1;
            NewFeatureTableInBarrels{d}(counter,:) =  [FeatureTable{d}(CellIndexInFeatureTable,1:end-1) SampleVariables{d}(Cell,:)];
        end
    end
    
     writetable(NewFeatureTableInBarrels{1,d},['OnlyCellsInBarrelsAllData',sprintf('%02d',d),'.csv']);
end

%% Aux Functions %%%%%%%%%%%%%%%%%%%%%%
function SurfData = SomaDepthIncode(SupportFolder,downsampleZ,DownsampleXY)
    cd(SupportFolder);
    Info = dir('*Tissue*');
    close all
    cmap = colormap(jet(length(Info)))
    x = [];
    y = [];
    z = [];

    for i = 1:downsampleZ:length(Info) 
         i
         im = imread(Info(i).name);
%          imagesc(im);
         im = imfill(im,'holes');
         [xtemp ,ytemp] = find(edge(im));

         x = [x; xtemp(1:DownsampleXY:end)];
         y = [y; ytemp(1:DownsampleXY:end)];
         z = [z; ones(length(xtemp(1:DownsampleXY:end,1)),1).*i];
    %      T = clusterdata(xtemp(1:10:end),ytemp(1:10:end),2);
    %      plot(
    end
          Data = single([x y z]);
          DownData = Data(1:DownsampleXY:end,:);
          T = clusterdata(DownData,2);
          SurfData1 = DownData(find(T==1),:);
          SurfData2 = DownData(find(T==2),:);
          figure
          hold
          plot3(SurfData1(:,1),SurfData1(:,2),SurfData1(:,3),'.r')
          plot3(SurfData2(:,1),SurfData2(:,2),SurfData2(:,3),'.g')
          legend('Surf1','Surf2');
    Decision = input('select correct surface (1/2)');      
    if Decision == 1
        SurfData = SurfData1;
    end

    if Decision == 2
        SurfData = SurfData2;
    end

end

function DSxyz4 = importPoints3(filename, startRow, endRow)
%IMPORTFILE2 Import numeric data from a text file as a matrix.
%   DSXYZ4 = IMPORTFILE2(FILENAME) Reads data from text file FILENAME for
%   the default selection.
%
%   DSXYZ4 = IMPORTFILE2(FILENAME, STARTROW, ENDROW) Reads data from rows
%   STARTROW through ENDROW of text file FILENAME.
%
% Example:
%   DSxyz4 = importfile2('DS_xyz4.txt', 2, 98);
%
%    See also TEXTSCAN.

% Auto-generated by MATLAB on 2019/07/23 16:19:29

%% Initialize variables.
delimiter = {',',' '};
if nargin<=2
    startRow = 2;
    endRow = inf;
end

%% Format for each line of text:
%   column3: double (%f)
%	column5: double (%f)
%   column7: double (%f)
% For more information, see the TEXTSCAN documentation.
formatSpec = '%*q%*q%f%*q%f%*q%f%*s%[^\n\r]';

%% Open the text file.
fileID = fopen(filename,'r');

%% Read columns of data according to the format.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', delimiter, 'TextType', 'string', 'HeaderLines', startRow(1)-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
for block=2:length(startRow)
    frewind(fileID);
    dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'TextType', 'string', 'HeaderLines', startRow(block)-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
    for col=1:length(dataArray)
        dataArray{col} = [dataArray{col};dataArrayBlock{col}];
    end
end

%% Close the text file.
fclose(fileID);

%% Post processing for unimportable data.
% No unimportable data rules were applied during the import, so no post
% processing code is included. To generate code which works for
% unimportable data, select unimportable cells in a file and regenerate the
% script.

%% Create output variable
DSxyz4 = [dataArray{1:end-1}];
end

function ShapeOut = ExpandBarrelShapes(ShapeIn,Factor)
NewPoints = zeros(size(ShapeIn.Points));     
COM = mean(ShapeIn.Points);
    for i = 1:length(ShapeIn.Points)
       NewPoint =  COM + Factor*([ShapeIn.Points(i,:) - COM]);
       NewPoints(i,:) = NewPoint;
    end
ShapeOut =  alphaShape(NewPoints,inf);
end


