
clc
clear 
close all

Shapes = [];

BarrelPoints = importPoints3('E:\Nadav\TempFileShare\Articles\Article_Reconstruction\Manuscript\TestBarrelIndtity\Sample19_Side1_points_onBarrel.points');
BarrelPoints = BarrelPoints*4;
idx = dbscan(BarrelPoints,1,5);
% idx = (idx-1);
% [~, MinCluster] = min([sum(idx==1); sum(idx==2)]);
% PointsCluster = MaxCluster-1;clc
% BorderCluster = ~PointsCluster;
%%
NumBorders = size(idx,1);
BorderIndices = [1; find(idx)];

%%
clear Shapes

x = BarrelPoints(:,1)';
y = BarrelPoints(:,2)';
z = BarrelPoints(:,3)';
B = [x(:) y(:) ones(size(x(:)))] \ z(:);
xv = linspace(min(x), max(x), 10)';
yv = linspace(min(y), max(y), 10)';
[X,Y] = meshgrid(xv, yv);
Z = reshape([X(:), Y(:), ones(size(X(:)))] * B, numel(xv), []);
[Nx,Ny,Nz] = surfnorm(X,Y,Z);

counter = 0;



NewPoints = cell(NumBorders,1);
for i = 1:NumBorders
   counter = counter + 1;
   
       %find plane
    Points = BarrelPoints([BorderIndices(i)+1:BorderIndices(i+1)-1],:);
%     x = Points(:,1)';
%     y = Points(:,2)';
%     z = Points(:,3)';
%     B = [x(:) y(:) ones(size(x(:)))] \ z(:);
%     xv = linspace(min(x), max(x), 10)';
%     yv = linspace(min(y), max(y), 10)';
%     [X,Y] = meshgrid(xv, yv);
%     Z = reshape([X(:), Y(:), ones(size(X(:)))] * B, numel(xv), []);
% 
%     [Nx,Ny,Nz] = surfnorm(X,Y,Z);


    shift = 250;
    tformPlus = affine3d([1 0 0 0; 0 1 0 0; 0 0 1 0; shift*Nx(1) shift*Ny(1) shift*Nz(1) 1]);
    tformMinus = affine3d([1 0 0 0; 0 1 0 0; 0 0 1 0; 2*shift*Nx(1) 2*shift*Ny(1) 2*shift*Nz(1) 1]);

    ptCloud = pointCloud(Points);
    ptCloudPlus = pctransform(ptCloud,tformPlus);
    ptCloudMinus = pctransform(ptCloud,tformMinus);
    
    NewPoints{counter} = [ptCloud.Location; ptCloudPlus.Location; ptCloudMinus.Location;];
    

  Shapes{counter} = alphaShape( NewPoints{counter},inf);
   
   
end

%% measuere eucledian distance  To top
 for d = 1:14
 clear Depth
     
     close all
cd(Directories{d})

load SurfData;
load([Directories{d},'\NormalizedBackground\Shaved\COMCoordinates']);
figure
CellOrientationVec = [0 0 0];
SurfClosePointmeanVecTemp = [0 0 0];
for i = 1:length(COMCoordinates)
   [SortDepth SortInd] = sort(pdist2(COMCoordinates(i,[2,1,3]),SurfData)'); 
   Depth(i)  = mean(SortDepth(1:10));
   SurfClosePointmeanVecTemp = mean(SurfData(SortInd(1:10),:));
   CellOrientationVec(i,:) =  SurfClosePointmeanVecTemp - COMCoordinates(i,[2,1,3]);
%    CellOrientationUnitVec(i,:) = CellOrientationUnitVec(i,:)./norm(CellOrientationUnitVec(i,:));
end

hold
% quiver3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),CellOrientationVec(:,1),CellOrientationVec(:,2),CellOrientationVec(:,3),2);
plot3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),'.r');
plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.k');
axis('equal')
CellOrientationVecUnit = CellOrientationVec./repmat(vecnorm(CellOrientationVec')',1,3);


figure
histfit(Depth,35,'kernel');
% Save data
cd(Directories{d})
save('Depth','Depth');
save('CellOrientationVecUnit','CellOrientationVecUnit');
 end

%% measuere eucledian distance  To bottom
% for d = 1:14
    close all
clear DepthBottom
for d = 1:14;
cd(Directories{d})

load BottomSurfData;
load([Directories{d},'\NormalizedBackground\Shaved\COMCoordinates']);
figure
CellOrientationVec = [0 0 0];
SurfClosePointmeanVecTemp = [0 0 0];
for i = 1:length(COMCoordinates)
   [SortDepth SortInd] = sort(pdist2(COMCoordinates(i,[2,1,3]),SurfData)'); 
   DepthBottom(i)  = mean(SortDepth(1:10));
   SurfClosePointmeanVecTemp = mean(SurfData(SortInd(1:10),:));
   CellOrientationVec(i,:) =  SurfClosePointmeanVecTemp - COMCoordinates(i,[2,1,3]);
%    CellOrientationUnitVec(i,:) = CellOrientationUnitVec(i,:)./norm(CellOrientationUnitVec(i,:));
end

hold
% quiver3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),CellOrientationVec(:,1),CellOrientationVec(:,2),CellOrientationVec(:,3),2);
plot3(COMCoordinates(:,2),COMCoordinates(:,1),COMCoordinates(:,3),'.r');
plot3(SurfData(:,1),SurfData(:,2),SurfData(:,3),'.k');
axis('equal')
CellOrientationVecUnit = CellOrientationVec./repmat(vecnorm(CellOrientationVec')',1,3);


figure(d)
histfit(DepthBottom,35,'kernel');
% Save data
cd(Directories{d})
save('DepthBottom','DepthBottom');
% save('CellOrientationVecUnit','CellOrientationVecUnit');
 end

%% 1st iteration
minDist = 100;
NewExpandedPoints = cell(NumBorders,1);
for counter = 1:NumBorders
  
   AllNewPoints = [];
   for ii = 1:NumBorders
       if ii ~= counter
            AllNewPoints = [AllNewPoints;  NewPoints{ii}];
       else
            AllNewPoints = [AllNewPoints;  zeros(length(NewPoints{ii}),3);];
       end
   end  
  
   for i = 1:length(NewPoints{counter});
       [Distance, Index] = pdist2(AllNewPoints,NewPoints{counter}(i,:),'euclidean','Smallest',1);	
        if Distance(1)<minDist %&& Distance(2)>minDist
            NewExpandedPoints{counter}(i,:) = [NewPoints{counter}(i,:) + AllNewPoints(Index(1),:)]/2;
%         end
%         if Distance(2)<minDist && Distance(1)>minDist
%            NewExpandedPoints{counter}(i,:) = [NewPoints{counter}(i,:) + AllNewPoints(Index(2),:)]/2;
%         end
%         if Distance(2)<minDist && Distance(1)<minDist
%            NewExpandedPoints{counter}(i,:) = [NewPoints{counter}(i,:) + AllNewPoints(Index(2),:)+ AllNewPoints(Index(1),:)]/3;
%         end
%         if Distance(2)>minDist && Distance(1)>minDist   
        else
            NewExpandedPoints{counter}(i,:) = NewPoints{counter}(i,:);
        end
   end
    Shapes{counter} = alphaShape( NewExpandedPoints{counter},inf);
   
end
%% 2nd iteration 

minDist = 100;
NewExpandedPoints2nd = cell(18,1);
for counter = 1:18
   ind = ones(18,1);
   ind(counter) = 0;
   AllNewPoints = [];
   for ii = 1:18
        AllNewPoints = [AllNewPoints;  NewExpandedPoints{ii}];
   end  
   Range = [(counter-1)*18+1:(counter)*18];
   AllNewPoints(Range,:) = zeros(18,3);
   for i = 1:18;
       [Distance, Index] = pdist2(AllNewPoints,NewExpandedPoints{counter}(i,:),'euclidean','Smallest',1)	
        if Distance(1) == 0 && Distance(2)<minDist
            NewExpandedPoints2nd{counter}(i,:) = [NewExpandedPoints{counter}(i,:) + AllNewPoints(Index(2),:)]/2;
%         end
%         if Distance(2)<minDist && Distance(1)>minDist
%            NewExpandedPoints{counter}(i,:) = [NewPoints{counter}(i,:) + AllNewPoints(Index(2),:)]/2;
%         end
%         if Distance(2)<minDist && Distance(1)<minDist
%            NewExpandedPoints{counter}(i,:) = [NewPoints{counter}(i,:) + AllNewPoints(Index(2),:)+ AllNewPoints(Index(1),:)]/3;
%         end
%         if Distance(2)>minDist && Distance(1)>minDist   
        else
            NewExpandedPoints2nd{counter}(i,:) = NewExpandedPoints{counter}(i,:);
        end
   end
   Shapes{counter} = alphaShape( NewExpandedPoints2nd{counter},inf);
   
end

%% clean Shapes 
% 
% for counter = 1:18
%    ind = ones(18,1);
%    ind(counter) = 0;
%    AllNewPoints = [];
%    for ii = 1:18
%         AllNewPoints = [AllNewPoints;  NewExpandedPoints{ii}];
%    end  
%    Range = [(counter-1)*18+1:(counter)*18];
%    AllNewPoints(Range,:) = zeros(18,3);
% 
%    InOut = inShape(Shapes{counter},AllNewPoints(:,1),AllNewPoints(:,2),AllNewPoints(:,3));
%    I = nearestNeighbor(Shapes{counter},AllNewPoints(InOut,1),AllNewPoints(InOut,2),AllNewPoints(InOut,3));
%    AllNewPointsFixed(InOut,:) = Shapes{counter}.Points(I,:);
%    
% end
% AllNewPointsFixed(AllNewPointsFixed(:,1)==0,:) = AllNewPoints(AllNewPointsFixed(:,1)==0,:);
% AllNewPointsFixed(307:324,:) = NewExpandedPoints{18};
% 
% for counter = 1:18
%     Range = [(counter-1)*18+1:(counter)*18];
%     Shapes{counter} =  alphaShape( AllNewPointsFixed(Range,:),inf);
% end

%%

close all
figure(3)
hold all
cmap = colormap(prism(NumBorders));
for i = 1:NumBorders
     plot(Shapes{i},'FaceColor',cmap(i,:))
    

end



%% load Somas
plot3(COMCoordinates(:,1),COMCoordinates(:,2),COMCoordinates(:,3),'.')

