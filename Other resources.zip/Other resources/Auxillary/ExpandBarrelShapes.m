function ShapeOut = ExpandBarrelShapes(ShapeIn,Factor)
NewPoints = zeros(size(ShapeIn.Points));     
COM = mean(ShapeIn.Points);
    for i = 1:length(ShapeIn.Points)
       NewPoint =  COM + Factor*([ShapeIn.Points(i,:) - COM]);
       NewPoints(i,:) = NewPoint;
    end
ShapeOut =  alphaShape(NewPoints,inf);
end


