% This script does initialization of the raytracer.
% So far it's just path check&add.
%
if isempty(strfind(path, 'raytracer-utils')),
    addpath( [fileparts(which('raytracer_trace_rays')) filesep 'raytracer-utils'] );
    savepath
end