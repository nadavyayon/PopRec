    clear A
    
    fname = 'NormalizedBackgroundSg-1.tif';

    info = imfinfo(fname);
    num_images = numel(info);
    for k = 1:num_images
        A(:,:,k) = imread(fname, k);
    end
    Lin = single(A(:));
    [Iadj , Radj, Nfound ] = neighbourND( 1:length(Lin), size(A), [1 1 1] );
    
    a = sort(Iadj');
    a = diff(a);
    values = [];
    NonEgdeRows = find((all(a)));
    values = Lin(Iadj(NonEgdeRows,:));
    values = [Lin(NonEgdeRows) values]; %add the center pixel
   
    
    [coeff,score,latent,tsquared,explained,mu] = pca(values,'NumComponents',3);

       SmallMat = score(1:100:end,:);
    
        [Clusters Identity OriginalIndexes]  = ClusterPoints3D([SmallMat(:,1) SmallMat(:,2) SmallMat(:,3)],1000,1000000,50,1);


    % hold on
    % plot(cmeans3(:,1),cmeans3(:,2),'ob','markersize',10,'markerfacecolor','b')


    ClusterCount(1) = sum(((Identity==1)));
    ClusterCount(2) = sum(((Identity==2)));
    [TissueValue TissueCluster] = max(ClusterCount');

    TissuePixelsIndex = OriginalIndexes(Identity==TissueCluster);
    TissuPixels = 
    BackroungPixels = find(cidx==find(ClusterMean~=TissueValue));
    
     plot(score(TissuePixels,1),score(TissuePixels,2),'.r')
     hold
     plot(score(BackroungPixels,1),score(BackroungPixels,2),'.b')
    
     BinaryImage = (A);
        BinaryImage(TissuePixels) = 0;
        BinaryImage(BackroungPixels) = 1;
        implay;