
function AutoConst_V1_1(FileDir,AnalysisFolder,CellNumber)

global cgui
cd(FileDir);
FileInfo = dir;
%cgui_tree;
stack = load_tree([FileDir,'\',FileInfo(CellNumber+2).name]);
save_tree(cgui.mtr.tree,[FileDir,'\mtr\',FileInfo(CellNumber+2).name(1:end-4),'.mtr']); 

close all force
end