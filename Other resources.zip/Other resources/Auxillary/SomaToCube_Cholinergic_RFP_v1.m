%% Soma detection and mini cube isolation latest 10.04.20 Nadav Yayon
function SomaToCube_Cholinergic_RFP_v1(FolderNorm16bitImages,ThresholdSomata,RangeDendrite)
clc
close all force

cd(FolderNorm16bitImages);
InfoNormFolder16bitImages = dir('*.tif');
NoOfImageFiles = find([InfoNormFolder16bitImages.bytes]>10*10000);
FirstImageFileIndex = find([InfoNormFolder16bitImages.bytes]>10*10000,1,'first');
FirstFileName = [InfoNormFolder16bitImages(FirstImageFileIndex).name];
SpaceInd = find(FirstFileName == ' ');
FirstFileName(SpaceInd) = '';% remove annoying space in file name
% addpath(AnalysisFolder);
NoOfImages = length(NoOfImageFiles);

 %% sample 10 images to determine threhold for general statistics and make 8bit images
Im = [];
for i = FirstImageFileIndex:FirstImageFileIndex+10 
 Imav = double(imread([FolderNorm16bitImages,'\',InfoNormFolder16bitImages(i).name]));
 Im = [Im Imav(:)];
end
 ImageSize = size(Imav);
clear Imav

%% convert to 8 bit for soma detection
MinBrighness = ThresholdSomata;
MaxBrighness = 65535;
mkdir('8bit');
cd([FolderNorm16bitImages,'\8bit']);
parfor i = 1:length(NoOfImageFiles)
     I = (imread([FolderNorm16bitImages,'\',InfoNormFolder16bitImages(i).name]));
     I = (imadjust(I,[MinBrighness/MaxBrighness; 1],[0; 256/MaxBrighness]));
     imwrite(uint8(I),['8bit_', sprintf('%3.4d',i),'.tif'],'tif');
end

%% 3D object counter - soma detection
clc

outputFolder = FolderNorm16bitImages;
threshold = 10;
minDiam = 10; %in pixels 
maxDiam = 20; %in pixels
cd([FolderNorm16bitImages,'\8bit']);
InfoFolder8bitImages = dir('*.tif');
tic
    
    IZLogical = false(2560,2160,length(InfoFolder8bitImages));
    i = 1;
    minIm = i;
    maxIm = length(InfoFolder8bitImages); %i+jumps+overlap-1;
    if maxIm > length(InfoFolder8bitImages); maxIm = length(InfoFolder8bitImages); end
    
    for ii = minIm:maxIm
        ii
     I = (imread([InfoFolder8bitImages(ii).name]));
     Ilogical = I>threshold;
     IZLogical(:,:,ii-i+1) = Ilogical;
    end
    CC = bwconncomp(IZLogical); 
    stats = regionprops3(CC,'Volume','Centroid','EquivDiameter','PrincipalAxisLength','BoundingBox'); 
    Somataind = find((stats.EquivDiameter<maxDiam).*(stats.EquivDiameter>minDiam));
    
    if i == 1 
        Somas = stats;
        Somas(1:length(Somataind),:) = Somas(Somataind,:);
        Somas(length(Somataind)+1:end,:) = [];
    else
         stats.Centroid(:,3) = stats.Centroid(:,3) + i;
         Somas = [Somas; stats(Somataind,:)];
    end
    toc

hist(Somas.EquivDiameter,20)


%% find duplicates 

for i = 1:size(Somas,1)
    BoundingBox = Somas(i,:).BoundingBox;
    Flag = 0;
    % z direction 
    if BoundingBox(3) == 0.5; Flag = 1; end
    if (BoundingBox(3)+ BoundingBox(6)) > length(InfoFolder8bitImages); Flag = 1; end
    if Flag; Somas{i,:} = 0;end
end
ToRemove = find(Somas.Volume == 0);
Somas(ToRemove,:) = [];

scatter3(Somas.Centroid(:,1),Somas.Centroid(:,2),Somas.Centroid(:,3));


%% save data
 
COMCoordinates = Somas.Centroid;
Diams = Somas.EquivDiameter;
save([[FolderNorm16bitImages],'\COMCoordinates.mat'],'COMCoordinates');
save([[FolderNorm16bitImages],'\SomaDiams.mat'],'Diams');
save([[FolderNorm16bitImages],'\Somas.mat'],'Somas');
save([[FolderNorm16bitImages],'\Stats.mat'],'stats');


%% convert to 8 bit for dendrites
close all;
MinBrighness = RangeDendrite(1);
MaxBrighness = RangeDendrite(2);

cd([FolderNorm16bitImages,'\8bit']);
mkdir 8bitDend
cd([FolderNorm16bitImages,'\8bit\8bitDend']);
parfor i = 1:length(NoOfImageFiles)
     I = (imread([FolderNorm16bitImages,'\',InfoNormFolder16bitImages(i).name]));
     I = (imadjust(I,[MinBrighness/65553; MaxBrighness/65553],[0; 1/256]));
     imwrite(uint8(I),['8bit_', sprintf('%3.4d',i),'.tif'],'tif');
end
%% Isolate Cube - close all open folders move files to cluster for analysis
cd([FolderNorm16bitImages,'\8bit\8bitDend']);
load([FolderNorm16bitImages,'\SomaDiams']);
load([FolderNorm16bitImages,'\COMCoordinates']);
imageXYZ = [ImageSize(2),ImageSize(1),NoOfImages]; %dimentions of stack 
mkdir('SingleCells')

% cd(AnalysisFolder)
tic
SomaCoordinates = IsolateCubeForEachCell_V1_3([FolderNorm16bitImages,'\8bit\8bitDend'],COMCoordinates,imageXYZ);
toc
end
