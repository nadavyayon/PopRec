function [SomaCoordinates, XYZCubeOrigins] = IsolateCubeForEachCell_V1_5(FolderPath,COMCoordinates,imageXYZ,CubeSize)
    cd(FolderPath);
    FolderInfo = dir('*.tif');
    SomaCoordinates = cell(length(COMCoordinates),1);
    
%     CubeSize = [400,400,300]

    cX = COMCoordinates(:,1);
    cY = COMCoordinates(:,2);
    cZ = COMCoordinates(:,3);
    cd SingleCells
    delete('*.tif'); % delete old file so that it wont append duplicates
    cd ..
    
    parfor Cell = 1:length(COMCoordinates) 
        Cell
        StartIm = max(1,round(cZ(Cell))-(CubeSize(3)/2));
        EndIm = min(imageXYZ(3)-1,round(cZ(Cell))+(CubeSize(3)/2));
        MinX = max(1,round(cX(Cell)-(CubeSize(1)/2)));
        MaxX = min(imageXYZ(1),round(cX(Cell)+(CubeSize(1)/2)));
        MinY = max(1,round(cY(Cell)-(CubeSize(2)/2)));
        MaxY = min(imageXYZ(2),round(cY(Cell)+(CubeSize(2)/2)));
        
%         cd(AnalysisFolder)
        AllSomasInCube = FindOtherSomasInCube(COMCoordinates,CubeSize,StartIm,EndIm,MinX,MaxX,MinY,MaxY,Cell);
%         cd(FolderPath);

        AllSomasInCube(find(AllSomasInCube==Cell)) = [];
        
        CurrentSoma = [cX(Cell)-MinX,cY(Cell)-MinY,cZ(Cell)-StartIm];
        
        OtherSomas =[];
        for i = 1:length(AllSomasInCube)
            OtherSomas(i,:) = [cX(AllSomasInCube(i))-MinX,cY(AllSomasInCube(i))-MinY,cZ(AllSomasInCube(i))-StartIm]; 
        end
        
        SomaCoordinates{Cell} =[CurrentSoma;OtherSomas];
        SomaCoordinates{Cell} = [fliplr(SomaCoordinates{Cell}(:,1:2)) SomaCoordinates{Cell}(:,3)];

        %Stack = zeros(MaxX-MinX+1,MaxY-MinY+1,EndIm-StartIm+1);
        counter = 0;
        NewFileName = ['Cell_',num2str(Cell,'%03d'),'.tif'];
 
        for i = StartIm:EndIm
            counter = counter+1;
            FullImage = imread(FolderInfo(i).name)';
            imwrite(FullImage(MinX+1:MaxX,MinY+1:MaxY)',[FolderPath,'\SingleCells\',NewFileName], 'WriteMode', 'append');
        end
%         cd SingleCells
%         movefile([FolderPath,'\',NewFileName])
%         cd ..
        XYZCubeOrigins(Cell,:) = [MinX MinY StartIm];

    end

save ('SomaCoordinates.mat','SomaCoordinates');

save ('XYZCubeOrigins.mat','XYZCubeOrigins');    
    
    
end

