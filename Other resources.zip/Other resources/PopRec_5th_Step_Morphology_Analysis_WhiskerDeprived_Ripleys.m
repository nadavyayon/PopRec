%analysis for whisker deprived mice 

%% Load data 
%close all 
clc
clear 
BatchDir = 'E:\PROJECTS\EMCU\4thWhiskerDeprived\SomaToCube\OutputOnlyBarrels';
cd(BatchDir) 
fileinfo = dir('*.csv');


DataFiles = cell(1,24);
for d = 1:24
   DataFiles{d} = readtable(fileinfo(d).name);
end

% A3 - Mouse_01_Side_00 - Left - UD
% A3 - Mouse_01_Side_01 - Right - UD
% A7 - Mouse_02_Side_00 - Right - RD
% A7 - Mouse_02_Side_01 - Left - RD
% D7 - Mouse_03_Side_00 - Left - RD
% D7 - Mouse_03_Side_01 - Right - RD
% A8 - Mouse_04_Side_00 - Left - LD
% A8 - Mouse_04_Side_01 - Right - LD
% B3 - Mouse_05_Side_00 - Right - UD 
% B3 - Mouse_05_Side_01 - Left - UD
% B5 - Mouse_06_Side_00 - Left - RD
% B5 - Mouse_06_Side_01 - Right - RD
% B6 - Mouse_07_Side_00 - Right - UD
% B6 - Mouse_07_Side_01 - Left - UD
% C4 - Mouse_08_Side_00 - Right - LD
% C4 - Mouse_08_Side_01 - Left - LD
% C8 - Mouse_09_Side_00 - Left - LD 
% C8 - Mouse_09_Side_01 - Right - LD
% D4 - Mouse_10_Side_00 - Right - RD 
% D4 - Mouse_10_Side_01 - Left - RD
% D6 - Mouse_11_Side_00 - Left - UD
% D6 - Mouse_11_Side_01 - Right - UD
% D3 - Mouse_12_Side_00 - Right - LD 
% D3 - Mouse_12_Side_01 - Left - LD


%Sample Number

SampleNo(1)=1;
SampleNo(2)=2;
SampleNo(3)=3;
SampleNo(4)=4;
SampleNo(5)=5;
SampleNo(6)=6;
SampleNo(7)=7;
SampleNo(8)=8;
SampleNo(9)=9;
SampleNo(10)=10;
SampleNo(11)=11;
SampleNo(12)=12;
SampleNo(13)=13;
SampleNo(14)=14;
SampleNo(15)=15;
SampleNo(16)=16;
SampleNo(17)=17;
SampleNo(18)=18;
SampleNo(19)=19;
SampleNo(20)=20;
SampleNo(21)=21;
SampleNo(22)=22;
SampleNo(23)=23;
SampleNo(24)=24;


%R is 0 L is 1

Sides(1)=1;
Sides(2)=0;
Sides(3)=0;
Sides(4)=1;
Sides(5)=1;
Sides(6)=0;
Sides(7)=1;
Sides(8)=0;
Sides(9)=0;
Sides(10)=1;
Sides(11)=1;
Sides(12)=0;
Sides(13)=0;
Sides(14)=1;
Sides(15)=0;
Sides(16)=1;
Sides(17)=1;
Sides(18)=0;
Sides(19)=0;
Sides(20)=1;
Sides(21)=1;
Sides(22)=0;
Sides(23)=0;
Sides(24)=1;


% 1 Is Deprived 0 is undeprived side

Deprived(1)=0;
Deprived(2)=0;
Deprived(3)=0;
Deprived(4)=1;
Deprived(5)=1;
Deprived(6)=0;
Deprived(7)=0;
Deprived(8)=1;
Deprived(9)=0;
Deprived(10)=0;
Deprived(11)=1;
Deprived(12)=0;
Deprived(13)=0;
Deprived(14)=0;
Deprived(15)=1;
Deprived(16)=0;
Deprived(17)=0;
Deprived(18)=1;
Deprived(19)=0;
Deprived(20)=1;
Deprived(21)=0;
Deprived(22)=0;
Deprived(23)=1;
Deprived(24)=0;

% 1 Is DeprivedMouse 0 is unDeprivedMouse 

DeprivedMouse(1)=0;	
DeprivedMouse(2)=0;	
DeprivedMouse(3)=1;	
DeprivedMouse(4)=1;	
DeprivedMouse(5)=1;	
DeprivedMouse(6)=1;	
DeprivedMouse(7)=1;	
DeprivedMouse(8)=1;	
DeprivedMouse(9)=0;	
DeprivedMouse(10)=0;	
DeprivedMouse(11)=1;	
DeprivedMouse(12)=1;	
DeprivedMouse(13)=0;	
DeprivedMouse(14)=0;	
DeprivedMouse(15)=1;	
DeprivedMouse(16)=1;	
DeprivedMouse(17)=1;	
DeprivedMouse(18)=1;	
DeprivedMouse(19)=1;	
DeprivedMouse(20)=1;	
DeprivedMouse(21)=0;	
DeprivedMouse(22)=0;	
DeprivedMouse(23)=1;	
DeprivedMouse(24)=1;	

% 1 include 0 exclude in analysis 

Include(1)=1;
Include(2)=1;
Include(3)=1;
Include(4)=1;
Include(5)=1;
Include(6)=1;
Include(7)=1;
Include(8)=1;
Include(9)=1;
Include(10)=1;
Include(11)=1;
Include(12)=1;
Include(13)=1;
Include(14)=1;
Include(15)=1;
Include(16)=1;
Include(17)=1;
Include(18)=1;
Include(19)=1;
Include(20)=1;
Include(21)=1;
Include(22)=1;
Include(23)=1;
Include(24)=1;


Batch(1)=1;
Batch(2)=1;
Batch(3)=1;
Batch(4)=1;
Batch(5)=1;
Batch(6)=1;
Batch(7)=1;
Batch(8)=1;
Batch(9)=1;
Batch(10)=1;
Batch(11)=1;
Batch(12)=1;
Batch(13)=1;
Batch(14)=1;
Batch(15)=1;
Batch(16)=1;
Batch(17)=1;
Batch(18)=1;
Batch(19)=1;
Batch(20)=1;
Batch(21)=1;
Batch(22)=1;
Batch(23)=1;
Batch(24)=1;

InternalMouseNumber(1)=1;
InternalMouseNumber(2)=1;
InternalMouseNumber(3)=2;
InternalMouseNumber(4)=2;
InternalMouseNumber(5)=3;
InternalMouseNumber(6)=3;
InternalMouseNumber(7)=4;
InternalMouseNumber(8)=4;
InternalMouseNumber(9)=5;
InternalMouseNumber(10)=5;
InternalMouseNumber(11)=6;
InternalMouseNumber(12)=6;
InternalMouseNumber(13)=7;
InternalMouseNumber(14)=7;
InternalMouseNumber(15)=8;
InternalMouseNumber(16)=8;
InternalMouseNumber(17)=9;
InternalMouseNumber(18)=9;
InternalMouseNumber(19)=10;
InternalMouseNumber(20)=10;
InternalMouseNumber(21)=11;
InternalMouseNumber(22)=11;
InternalMouseNumber(23)=12;
InternalMouseNumber(24)=12;


% Sex
% A3 - F
% A7 - F
% D7 - M
% A8 - M
% B3 - M
% B5 - M
% B6 - F
% C4 - M
% C8 - F
% D4 - F
% D6 - M
% D3 - M

%0 is male, 1 - Female
Gender(1)=1;
Gender(2)=1;
Gender(3)=1;
Gender(4)=1;
Gender(5)=0;
Gender(6)=0;
Gender(7)=0;
Gender(8)=0;
Gender(9)=0;
Gender(10)=0;
Gender(11)=0;
Gender(12)=0;
Gender(13)=1;
Gender(14)=1;
Gender(15)=0;
Gender(16)=0;
Gender(17)=1;
Gender(18)=1;
Gender(19)=1;
Gender(20)=1;
Gender(21)=0;
Gender(22)=0;
Gender(23)=0;
Gender(24)=0;


%%  Feature Selection

Fetures = DataFiles{1,1}.Properties.VariableNames
  
   


%% For deprived vs undeprived 
close all
clc
AllData = [DataFiles];
AllDataTag = array2table(zeros(1,length(Fetures)+8));
AllDataTag.Properties.VariableNames = [Fetures, {'Side'},{'Deprived'},{'Deprived_Mouse'},{'include'},{'batch'},{'Internal_No'},{'Sex'},{'SampleNo'}];

for d = 1:length(AllData)
    HightTemp = height(AllData{d});    
    Tm = ones(HightTemp,1);
    M = [Tm*Sides(d) Tm*Deprived(d) Tm*DeprivedMouse(d) Tm*Include(d) Tm*Batch(d) Tm*InternalMouseNumber(d) Tm*Gender(d) Tm*SampleNo(d)];
    Mt = array2table(M);
    Mt.Properties.VariableNames = [{'Side'},{'Deprived'},{'Deprived_Mouse'},{'include'},{'batch'},{'Internal_No'},{'Sex'},{'SampleNo'}];
    AllDataTag = [AllDataTag;  [AllData{d}(:,Fetures) Mt]];
end
All_Data_Tag = AllDataTag(2:end,:);

%% save data
writetable(All_Data_Tag,'MegaTable_Whisker_deprived.csv','Delimiter',',')  

